"use client";

import { useEffect, useState } from "react";
import type { NewsPost } from "../lib/news-cms";

type Post = NewsPost & { assets: { id: string; name: string; url: string }[] };
type Account = { username: string; role: "admin" | "editor"; mustChangePassword: boolean; enabled: boolean };
async function api<T>(path: string, body?: unknown, method = "POST"): Promise<T> {
  const response = await fetch(`/api/news-cms/${path}`, { cache: "no-store", ...(body !== undefined ? { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {}) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || "Не удалось выполнить действие.");
  return data;
}
const dateLabel = (value: string) => new Date(value + "T12:00:00").toLocaleDateString("ru-RU");
const emptyPost = (): Post => ({ id: "", kind: "news", title: "", body: "", category: "Компания", event_date: new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Moscow" }).format(new Date()), status: "draft", version: 1, updated_at: "", assets: [] });

export function PublishedNews({ albums = false, query = "", topic = "Все" }: { albums?: boolean; query?: string; topic?: string }) {
  const [posts, setPosts] = useState<Post[]>([]), [error, setError] = useState(""), [selected, setSelected] = useState<Post | null>(null);
  const load = () => { setError(""); api<{ posts: Post[] }>("feed").then(data => setPosts(data.posts)).catch(e => setError(e.message)); };
  useEffect(load, []);
  useEffect(() => {
    if (!selected) return;
    const oldOverflow = document.body.style.overflow, previous = document.activeElement as HTMLElement | null;
    document.body.style.overflow = "hidden";
    const dialog = document.getElementById(albums ? "news-album-dialog" : "news-post-dialog");
    dialog?.querySelector<HTMLButtonElement>("button")?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelected(null);
      if (e.key === "Tab" && dialog) {
        const controls = Array.from(dialog.querySelectorAll<HTMLElement>('button,a[href],input,[tabindex="0"]')), first = controls[0], last = controls.at(-1);
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", key);
    return () => { document.body.style.overflow = oldOverflow; document.removeEventListener("keydown", key); previous?.focus(); };
  }, [selected, albums]);
  const visible = posts.filter(p => (p.kind === "album") === albums && (!query || `${p.title} ${p.body} ${p.category}`.toLowerCase().includes(query.toLowerCase())) && (albums || topic === "Все" || p.category === topic));
  return <div className={`news-published ${albums ? "news-published-albums" : ""}`}>
    {error && <p role="alert">Публикации временно недоступны. <button onClick={load}>Повторить</button></p>}
    {visible.map(p => <article className="news-published-card" key={p.id}>
      <button className="news-published-open" onClick={() => setSelected(p)}>
        {p.assets[0] && <img src={p.assets[0].url} alt="" loading="lazy" />}
        <span><small>{p.kind === "album" ? `${p.assets.length} фото` : p.category} · {dateLabel(p.event_date)}</small><strong>{p.title}</strong><span>{p.body.slice(0, 180)}{p.body.length > 180 ? "…" : ""}</span><b>{albums ? "Смотреть фотографии" : "Читать новость"} →</b></span>
      </button>
    </article>)}
    {selected && <div className="news-cms-overlay" onClick={e => { if (e.target === e.currentTarget) setSelected(null); }}>
      <section className="news-cms-reader" id={albums ? "news-album-dialog" : "news-post-dialog"} role="dialog" aria-modal="true" aria-labelledby={albums ? "news-album-title" : "news-post-title"}>
        <button className="news-cms-close" onClick={() => setSelected(null)} aria-label="Закрыть публикацию">×</button>
        <p>{selected.category} · {dateLabel(selected.event_date)}</p><h2 id={albums ? "news-album-title" : "news-post-title"}>{selected.title}</h2><p className="news-cms-body">{selected.body}</p>
        <div className="news-cms-reader-photos">{selected.assets.map(a => <figure key={a.id}><img src={a.url} alt={a.name} loading="lazy" /></figure>)}</div>
      </section>
    </div>}
  </div>;
}

export function NewsManagement() {
  const [user, setUser] = useState<Account | null>(null), [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(""), [message, setMessage] = useState("");
  const [username, setUsername] = useState(""), [password, setPassword] = useState(""), [currentPassword, setCurrentPassword] = useState(""), [newPassword, setNewPassword] = useState(""), [repeatPassword, setRepeatPassword] = useState("");
  const [posts, setPosts] = useState<Post[]>([]), [editing, setEditing] = useState<Post | null>(null), [dirty, setDirty] = useState(false), [tab, setTab] = useState<"news" | "album" | "accounts">("news"), [filter, setFilter] = useState("all"), [accounts, setAccounts] = useState<Account[]>([]), [resetPassword, setResetPassword] = useState(""), [passwordOpen, setPasswordOpen] = useState(false);
  const refresh = async (account = user) => {
    if (!account || account.mustChangePassword) return;
    setPosts((await api<{ posts: Post[] }>("posts")).posts);
    if (account.role === "admin") setAccounts((await api<{ users: Account[] }>("accounts")).users);
  };
  useEffect(() => { api<{ user: Account | null }>("session").then(async data => { setUser(data.user); await refresh(data.user); }).catch(e => setError(e.message)).finally(() => setReady(true)); }, []);
  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", warn); return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  const run = async (action: () => Promise<void>) => { setBusy(true); setError(""); setMessage(""); try { await action(); } catch (e) { setError(e instanceof Error ? e.message : "Не удалось выполнить действие."); } finally { setBusy(false); } };
  const discard = () => !dirty || window.confirm("Есть несохранённые изменения. Выйти без сохранения?");
  const open = (post: Post | null) => { if (discard()) { setEditing(post); setDirty(false); setMessage(""); setError(""); } };
  const update = (patch: Partial<Post>) => { if (editing) { setEditing({ ...editing, ...patch }); setDirty(true); } };
  const save = async (status: "draft" | "published") => {
    if (!editing) return;
    const data = await api<{ post: Post }>(`posts${editing.id ? "/" + editing.id : ""}`, { ...editing, status }, editing.id ? "PATCH" : "POST");
    setEditing(data.post); setDirty(false); await refresh(); setMessage(status === "published" ? "Опубликовано. Материал доступен сотрудникам в «Новостях»." : "Черновик сохранён.");
  };
  const logout = async () => { await api("logout", {}); setUser(null); setPosts([]); setAccounts([]); setEditing(null); setDirty(false); setPassword(""); };
  const passwordForm = <form className="news-cms-form" onSubmit={e => { e.preventDefault(); void run(async () => {
    if (newPassword !== repeatPassword) throw new Error("Новые пароли не совпадают.");
    await api("password", { currentPassword, password: newPassword }); setCurrentPassword(""); setNewPassword(""); setRepeatPassword(""); setPasswordOpen(false); setUser(null); setPosts([]); setEditing(null); setDirty(false); setMessage("Пароль изменён. Войдите с новым паролем.");
  }); }}>
    <h2>{user?.mustChangePassword ? "Замените временный пароль" : "Изменить пароль"}</h2>
    <label>Текущий пароль<input type="password" autoComplete="current-password" required maxLength={128} value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} /></label>
    <label>Новый пароль<input type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={newPassword} onChange={e => setNewPassword(e.target.value)} /></label>
    <small>От 12 до 128 символов, буквы и цифры.</small>
    <label>Повторите новый пароль<input type="password" autoComplete="new-password" required minLength={12} maxLength={128} value={repeatPassword} onChange={e => setRepeatPassword(e.target.value)} /></label>
    <button className="news-cms-primary" disabled={busy}>Сохранить пароль</button>
    {!user?.mustChangePassword && <button type="button" onClick={() => setPasswordOpen(false)}>Отмена</button>}
  </form>;
  return <main className="news-cms">
    <header className="news-cms-header"><a href="/?section=news" className="news-cms-brand"><img src="/bio-logo.png" alt="BIO" /><span>Редакция новостей</span></a><a href="/?section=news">Перейти к новостям →</a></header>
    {!ready ? <p role="status">Проверяем вход…</p> : <>
      {error && <p className="news-cms-error" role="alert">{error}</p>}{message && <p className="news-cms-success" role="status">{message}</p>}
      {!user ? <section className="news-cms-login"><p className="news-cms-eyebrow">НОВОСТИ BIO</p><h1>Вход в редакцию</h1><p>Для редактора и администратора раздела.</p>
        <form className="news-cms-form" onSubmit={e => { e.preventDefault(); void run(async () => { const data = await api<{ user: Account }>("login", { username, password }); setUser(data.user); setPassword(""); await refresh(data.user); }); }}>
          <label>Логин<input name="username" autoComplete="username" required maxLength={100} autoCapitalize="none" spellCheck={false} value={username} onChange={e => setUsername(e.target.value)} /></label>
          <label>Пароль<input name="password" type="password" autoComplete="current-password" required maxLength={128} value={password} onChange={e => setPassword(e.target.value)} /></label>
          <button className="news-cms-primary" disabled={busy}>{busy ? "Входим…" : "Войти"}</button>
        </form>
      </section> : <>
        <div className="news-cms-account"><span><strong>{user.username}</strong> · {user.role === "admin" ? "Администратор новостей" : "Редактор"}</span><div>{!user.mustChangePassword && <button disabled={busy} onClick={() => { if (discard()) { setEditing(null); setDirty(false); setPasswordOpen(true); } }}>Изменить пароль</button>}<button disabled={busy} onClick={() => { if (discard()) void run(logout); }}>Выйти</button></div></div>
        {user.mustChangePassword || passwordOpen ? <section className="news-cms-login">{passwordForm}</section> : <>
          <div className="news-cms-title"><div><p className="news-cms-eyebrow">УПРАВЛЕНИЕ КОНТЕНТОМ</p><h1>Новости и события BIO</h1><p>Публикации и фотографии для сотрудников.</p></div>{tab !== "accounts" && <button className="news-cms-primary" disabled={busy} onClick={() => open({ ...emptyPost(), kind: tab, category: tab === "album" ? "Корпоратив" : "Компания" })}>{tab === "album" ? "+ Создать альбом" : "+ Добавить новость"}</button>}</div>
          <nav className="news-cms-tabs" aria-label="Разделы редакции">{(["news", "album", ...(user.role === "admin" ? ["accounts"] : [])] as const).map(value => <button key={value} disabled={busy} aria-current={tab === value ? "page" : undefined} onClick={() => { if (discard()) { setTab(value as typeof tab); setEditing(null); setDirty(false); setError(""); setMessage(""); } }}>{value === "news" ? "Новости" : value === "album" ? "Фото с мероприятий" : "Учётные записи"}</button>)}</nav>
          {tab === "accounts" && user.role === "admin" ? <section className="news-cms-panel"><h2>Доступ к редакции</h2>{accounts.map(a => <div className="news-cms-user" key={a.username}><div><strong>{a.username}</strong><p>{a.role === "admin" ? "Все публикации и управление доступом" : "Новости, черновики и фотоальбомы"}</p><small>{a.enabled ? "Доступ активен" : "Доступ заблокирован"}{a.mustChangePassword ? " · Нужно сменить пароль" : ""}</small></div>{a.role === "editor" && <button disabled={busy} onClick={() => void run(async () => { await api("accounts/editor", { enabled: !a.enabled }, "PATCH"); await refresh(); setMessage(a.enabled ? "Доступ редактора заблокирован, его сеансы завершены." : "Доступ редактора восстановлен."); })}>{a.enabled ? "Заблокировать" : "Разблокировать"}</button>}</div>)}
            <form className="news-cms-form" onSubmit={e => { e.preventDefault(); void run(async () => { await api("accounts/editor", { password: resetPassword }, "PATCH"); setResetPassword(""); await refresh(); setMessage("Временный пароль редактора обновлён. Передайте его редактору: при входе потребуется смена."); }); }}><h3>Сбросить пароль editor</h3><label>Новый временный пароль<input type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={resetPassword} onChange={e => setResetPassword(e.target.value)} /></label><button disabled={busy}>Сбросить пароль</button></form>
          </section> : editing ? <section className="news-cms-panel"><form onSubmit={e => { e.preventDefault(); void run(() => save("draft")); }} className="news-cms-editor">
            <div className="news-cms-editor-head"><h2>{editing.id ? "Редактирование" : editing.kind === "album" ? "Новый фотоальбом" : "Новая новость"}</h2><button type="button" disabled={busy} onClick={() => open(null)}>К списку</button></div>
            <p className="news-cms-status">{editing.status === "published" ? "Опубликовано" : "Черновик"}{dirty ? " · Есть несохранённые изменения" : ""}</p>
            <label>Название<input required maxLength={180} value={editing.title} onChange={e => update({ title: e.target.value })} /></label>
            <div className="news-cms-fields"><label>Дата события<input type="date" required value={editing.event_date} onChange={e => update({ event_date: e.target.value })} /></label><label>Категория<select value={editing.category} onChange={e => update({ category: e.target.value })}>{["Компания", "Исследования", "Адаптация", "Команда", "Проекты", "Полезное", "Важно", "Корпоратив", "Обучение", "Персонал", "Закупки", "Логистика", "Объявление"].map(c => <option key={c}>{c}</option>)}</select></label></div>
            <label>{editing.kind === "album" ? "Описание альбома" : "Текст новости"}<textarea rows={9} maxLength={30000} value={editing.body} onChange={e => update({ body: e.target.value })} /></label>
            <section className="news-cms-uploads"><h3>Фотографии · {editing.assets.length}/20</h3><p>JPG, PNG или WebP, до 5 МБ на фото.</p>{!editing.id ? <p>Сохраните черновик, чтобы добавить фотографии.</p> : <label className="news-cms-upload-label">Добавить фотографии<input type="file" multiple accept="image/jpeg,image/png,image/webp" disabled={busy || editing.assets.length >= 20} onChange={e => { const files = Array.from(e.target.files || []); e.target.value = ""; void run(async () => {
              if (files.length + editing.assets.length > 20) throw new Error("Не больше 20 фото в одной публикации.");
              if (files.some(f => f.size > 5 * 1024 * 1024 || !f.size)) throw new Error("Каждое фото должно быть не больше 5 МБ.");
              let current = editing;
              for (const file of files) {
                const body = new FormData(); body.set("photo", file);
                const response = await fetch(`/api/news-cms/upload/${editing.id}`, { method: "POST", body }); const data = await response.json();
                if (!response.ok) throw new Error(data.error?.message || "Не удалось загрузить фото.");
                current = { ...current, assets: data.post.assets }; setEditing(current);
              }
              await refresh(); setMessage(`Фотографии добавлены: ${files.length}.`);
            }); }} /></label>}
              <div className="news-cms-photo-grid">{editing.assets.map(a => <figure key={a.id}><img src={a.url} alt={a.name} /><figcaption>{a.name}</figcaption><button type="button" disabled={busy} onClick={() => { if (window.confirm("Удалить эту фотографию?")) void run(async () => { const data = await api<{ post: Post }>(`assets/${a.id}`, {}, "DELETE"); setEditing({ ...editing, assets: data.post.assets }); await refresh(); }); }}>Удалить фото</button></figure>)}</div>
            </section>
            <footer className="news-cms-editor-actions"><button type="submit" disabled={busy}>{editing.status === "published" ? "Сохранить и снять с публикации" : "Сохранить черновик"}</button><button type="button" className="news-cms-primary" disabled={busy} onClick={() => { if (editing.title.trim()) void run(() => save("published")); else setError("Укажите название публикации."); }}>{editing.status === "published" ? "Сохранить публикацию" : "Опубликовать"}</button>{editing.id && <button type="button" className="news-cms-danger" disabled={busy} onClick={() => { if (window.confirm("Удалить публикацию и все её фотографии?")) void run(async () => { await api(`posts/${editing.id}`, {}, "DELETE"); setEditing(null); setDirty(false); await refresh(); setMessage("Публикация удалена."); }); }}>Удалить публикацию</button>}</footer>
          </form></section> : <section className="news-cms-panel"><div className="news-cms-list-head"><h2>{tab === "album" ? "Фотоальбомы" : "Публикации"}</h2><label>Статус<select value={filter} onChange={e => setFilter(e.target.value)}><option value="all">Все</option><option value="draft">Черновики</option><option value="published">Опубликованные</option></select></label><button disabled={busy} onClick={() => void run(() => refresh())}>Обновить</button></div>
            {posts.filter(p => p.kind === tab && (filter === "all" || p.status === filter)).length === 0 && <div className="news-cms-empty"><h3>Пока нет {filter === "draft" ? "черновиков" : filter === "published" ? "публикаций" : tab === "album" ? "альбомов" : "новостей"}</h3><p>Добавьте первый материал с помощью кнопки выше.</p></div>}
            {posts.filter(p => p.kind === tab && (filter === "all" || p.status === filter)).map(p => <article key={p.id} className="news-cms-list-item"><div>{p.assets[0] && <img src={p.assets[0].url} alt="" />}<span><strong>{p.title}</strong><small>{dateLabel(p.event_date)} · {p.status === "published" ? "Опубликовано" : "Черновик"} · {p.assets.length} фото</small></span></div><button disabled={busy} onClick={() => open(p)}>Редактировать</button></article>)}
          </section>}
          {busy && <p role="status" className="news-cms-busy">Сохраняем изменения…</p>}
        </>}
      </>}
    </>}
  </main>;
}
