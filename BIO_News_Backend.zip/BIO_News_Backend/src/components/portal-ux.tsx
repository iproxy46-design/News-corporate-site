"use client";
import {useEffect,useRef,useState,type ReactNode} from "react";
export async function requestJson<T>(url: string, init: RequestInit = {}): Promise<T> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), init.body instanceof FormData ? 90000 : 15000);
  const abort = () => controller.abort();
  init.signal?.addEventListener("abort", abort, { once: true });
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const value = await response.json();
    if (!response.ok) throw new Error(value.error?.message ?? "Не удалось выполнить действие. Попробуйте ещё раз.");
    return value;
  } finally { window.clearTimeout(timer); init.signal?.removeEventListener("abort", abort); }
}
export type PortalNavigate = (section: string, params?: Record<string, string>) => void;
export function PortalDialog({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const ref = useRef<HTMLElement>(null);
  const close = useRef(onClose); close.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    const dialog = ref.current;
    const elements = () => [...dialog!.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex="0"]')].filter((e) => e.getClientRects().length > 0);
    (elements()[1] ?? elements()[0] ?? dialog)?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); close.current(); }
      if (event.key === "Tab") { const all = elements(); if (all.length && event.shiftKey && document.activeElement === all[0]) { event.preventDefault(); all.at(-1)!.focus(); } else if (all.length && !event.shiftKey && document.activeElement === all.at(-1)) { event.preventDefault(); all[0].focus(); } }
    };
    document.addEventListener("keydown", key);
    return () => { document.body.style.overflow = overflow; document.removeEventListener("keydown", key); previous?.focus(); };
  }, []);
  return <div className="ux-modal-overlay"><button className="ux-modal-scrim" onClick={onClose} aria-label="Закрыть окно" /><article ref={ref} className="ux-modal" role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}><header><h2>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Закрыть">×</button></header>{children}</article></div>;
}