"use client";
import { useEffect, useState } from "react";
import { birthdaysInMonth, birthdaysToday, newsBirthdays, type NewsBirthday } from "../lib/news-birthdays";
import { SectionIcon } from "./section-icon";

type Reaction = { recipientId: string; count: number; liked: boolean; canLike: boolean };
const months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
export function NewsBirthdays({ onOpen, cityFor }: { onOpen: (person: NewsBirthday) => void; cityFor: (person: NewsBirthday) => string }) {
  const [mode, setMode] = useState<"today" | "month">("today"), [today, setToday] = useState(() => new Date());
  useEffect(() => { const timer = setInterval(() => setToday(new Date()), 60000); return () => clearInterval(timer); }, []);
  const [month, setMonth] = useState(() => Number(new Intl.DateTimeFormat("en", { timeZone: "Europe/Moscow", month: "numeric" }).format(new Date())));
  const [reactions, setReactions] = useState<Reaction[]>([]), [ready, setReady] = useState(false), [error, setError] = useState(""), [busy, setBusy] = useState<string[]>([]), [notice, setNotice] = useState("");
  const load = async () => {
    setError(""); setReady(false);
    try { const r = await fetch("/api/birthdays/likes", { cache: "no-store" }), data = await r.json(); if (!r.ok) throw new Error(data.error?.message || "Не удалось загрузить поздравления."); setReactions(data.items); setReady(true); }
    catch (e) { setError(e instanceof Error ? e.message : "Ошибка загрузки поздравлений."); }
  };
  useEffect(() => { void load(); }, []);
  const like = async (person: NewsBirthday, liked: boolean) => {
    setBusy(current => [...current, person.id]); setError(""); setNotice("");
    try {
      const r = await fetch("/api/birthdays/likes", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ recipientId: person.id, liked }) }), data = await r.json();
      if (!r.ok) throw new Error(data.error?.message || "Не удалось сохранить поздравление.");
      // Update only this colleague: parallel responses must not overwrite other likes.
      setReactions(current => current.map(row => row.recipientId === person.id ? data.items.find((item: Reaction) => item.recipientId === person.id) : row));
      setNotice(liked ? `Вы поздравили: ${person.name}` : `Поздравление отменено: ${person.name}`);
    } catch (e) { setError(e instanceof Error ? e.message : "Поздравление не сохранено."); }
    finally { setBusy(current => current.filter(id => id !== person.id)); }
  };
  const people = mode === "today" ? birthdaysToday(today) : birthdaysInMonth(month);
  const isExample = people.length === 0;
  const displayedPeople = !isExample ? people : mode === "today" ? [newsBirthdays[0]] : newsBirthdays.map(person => ({
    ...person, month,
    meta: `${new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long" }).format(new Date(2026, month - 1, person.day))} · ${person.meta.split(" · ")[1]}`,
  }));
  return <article className="card news-birthday-v2 news-monthly-birthdays">
    <header><div className="news-section-title"><SectionIcon name="balloon" /><h3 className="cabinet-block-heading">Именинники</h3></div><span aria-label={`Именинников ${mode === "today" ? "сегодня" : "в месяце"}: ${people.length}`}>{isExample ? `Пример · ${displayedPeople.length}` : people.length}</span></header>
    <div className="news-birthday-tabs" role="tablist" aria-label="Период именинников"><button role="tab" aria-selected={mode === "today"} aria-controls="news-birthday-panel" id="news-birthday-today-tab" onClick={() => { setMode("today"); setNotice(""); }}>Сегодня</button><button role="tab" aria-selected={mode === "month"} aria-controls="news-birthday-panel" id="news-birthday-month-tab" onClick={() => { setMode("month"); setNotice(""); }}>Месяц</button></div>
    <div id="news-birthday-panel" role="tabpanel" aria-labelledby={mode === "today" ? "news-birthday-today-tab" : "news-birthday-month-tab"}>
    {mode === "month" && <label className="news-birthday-month">Месяц<select aria-label="Месяц именинников" value={month} onChange={e => { setMonth(Number(e.target.value)); setNotice(""); }}>{months.map((label, i) => <option value={i + 1} key={label}>{label}{newsBirthdays.some(p => p.month === i + 1) ? ` · ${birthdaysInMonth(i + 1).length}` : ""}</option>)}</select></label>}
    {isExample && <p className="news-birthday-example-label">{mode === "today" ? "Пример карточки именинника" : `Пример списка именинников · ${months[month - 1].toLowerCase()}`}</p>}
    {displayedPeople.length ? <ul className={`news-birthday-month-list ${mode === "today" ? "news-birthday-today-grid" : ""}`}>{displayedPeople.map(person => {
      const reaction = reactions.find(r => r.recipientId === person.id);
      return <li key={person.id}>
        <button className="news-birthday-person" onClick={() => onOpen(person)} aria-label={`Открыть карточку сотрудника: ${person.name}`}><img src={person.photo} style={{ objectPosition: person.position }} alt="" /><span><strong>{person.name}</strong><small>{mode === "today" ? person.meta.split(" · ")[1] : person.meta}</small>{mode === "today" && <small>{cityFor(person)}</small>}</span></button>
        <button className={`news-birthday-like ${reaction?.liked ? "is-liked" : ""}`} type="button" aria-pressed={!!reaction?.liked} aria-label={`${reaction?.liked ? "Отменить поздравление" : "Подарить лайк-поздравление"}: ${person.name}`} disabled={!ready || busy.includes(person.id) || !reaction?.canLike} title={reaction?.canLike === false ? "Поздравьте коллегу" : "Нажмите на подарок, чтобы поздравить коллегу лайком"} onClick={() => void like(person, !reaction?.liked)}><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" aria-hidden="true"><path d="M3 8h18v4H3zM5 12v9h14v-9M12 8v13"/><path d="M12 8H8.5A2.5 2.5 0 1 1 11 5.5L12 8Zm0 0h3.5A2.5 2.5 0 1 0 13 5.5L12 8Z"/></svg><span>{reaction?.count ?? "—"}</span></button>
      </li>;
    })}</ul> : <p className="news-birthday-empty">{mode === "today" ? "Сегодня в списке нет именинников. Посмотрите дни рождения во вкладке «Месяц»." : "На этот месяц в списке пока нет дат рождения."}</p>}
    {mode === "today" && <div className="news-birthday-company"><span aria-hidden="true">✦</span><div><strong>С днём рождения от команды BIO!</strong><p>Желаем нашим именинникам здоровья, радости и вдохновения. Пусть рядом будут близкие люди, а впереди — интересные задачи, яркие события и новые достижения!</p></div></div>}
    </div>
    {error && <p className="news-birthday-feedback" role="alert">{error} <button onClick={() => void load()}>Повторить</button></p>}
    <span className="news-birthday-feedback" role="status">{notice}</span>
  </article>;
}

export function NewsViews({ count }: { count: number }) {
  return <span className="news-view-count" aria-label={`${count} просмотров`} title="Просмотры"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" /></svg>{count}</span>;
}
