"use client";

import { useState } from "react";

type EmployeePortraitProps = {
  name: string;
  role: string;
  src?: string;
  initials?: string;
  position?: string;
  online?: boolean;
  priority?: boolean;
  headingId?: string;
  headingLevel?: "h2" | "h3";
};

export function EmployeePortrait({
  name,
  role,
  src,
  initials,
  position = "center 28%",
  online,
  priority = false,
  headingId,
  headingLevel: Heading = "h2",
}: EmployeePortraitProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);
  const hasPhoto = Boolean(src && failedSrc !== src);
  const fallback = initials || name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("");

  return (
    <figure className={`employee-portrait ${hasPhoto ? "has-photo" : "has-initials"}`}>
      {hasPhoto ? (
        <img
          src={src}
          alt={`Фото сотрудника ${name}`}
          width={640}
          height={800}
          decoding="async"
          loading={priority ? "eager" : "lazy"}
          fetchPriority={priority ? "high" : "auto"}
          style={{ objectPosition: position }}
          onError={() => setFailedSrc(src ?? null)}
        />
      ) : (
        <span className="employee-portrait-initials" role="img" aria-label={`Фото сотрудника ${name} недоступно`}>
          {fallback}
        </span>
      )}
      {online && (
        <span className="employee-portrait-online" aria-label="В сети">
          <i aria-hidden="true" />
          На связи
        </span>
      )}
      <figcaption>
        <Heading id={headingId}>{name}</Heading>
        <p>{role}</p>
      </figcaption>
    </figure>
  );
}
