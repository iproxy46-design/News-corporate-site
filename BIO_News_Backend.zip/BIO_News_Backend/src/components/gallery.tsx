"use client";

import { useEffect, useId, useRef, useState } from "react";
import { galleryPhotos, type GalleryPhoto } from "../lib/gallery";
import { MaterialIcon } from "./material-icon";
import { SectionIcon } from "./section-icon";
import { useGalleryFavorites } from "./use-gallery-favorites";
import { PublishedNews } from "./news-publishing";

type Favorites = ReturnType<typeof useGalleryFavorites>;

function FavoriteButton({ photo, favorites }: { photo: GalleryPhoto; favorites: Favorites }) {
  const selected = favorites.photoIds.has(photo.id), busy = favorites.pendingIds.has(photo.id);
  const label = selected ? "Убрать из избранного" : "Добавить в избранное";
  return <button type="button" className={`gallery-favorite-button${selected ? " selected" : ""}`}
    aria-label={`${label}: ${photo.title}`} title={label} aria-pressed={selected} aria-busy={busy}
    disabled={!favorites.ready || favorites.loading || busy} onClick={() => void favorites.setFavorite(photo.id, !selected)}>
    <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill={selected ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
      <path d="m12 3 2.8 5.7 6.3.9-4.55 4.43L17.62 20 12 17.04 6.38 20l1.07-5.97L2.9 9.6l6.3-.9L12 3Z" />
    </svg>
  </button>;
}

function PhotoCard({ photo, favorites, onOpen, featured = false }: { photo: GalleryPhoto; favorites: Favorites; onOpen: () => void; featured?: boolean }) {
  return <article className={`gallery-photo-card${featured ? " featured" : ""}`}>
    <button type="button" className="gallery-photo-open" onClick={onOpen} aria-label={`Открыть фото: ${photo.title}`}
      style={{ backgroundImage: `linear-gradient(180deg,transparent 35%,rgba(20,22,19,.84)),url(${photo.src})`, backgroundPosition: photo.position ?? "center" }}>
      <span><strong>{photo.title}</strong><time>{photo.date}</time></span>
    </button>
    <FavoriteButton photo={photo} favorites={favorites} />
  </article>;
}

function GalleryFeedback({ favorites }: { favorites: Favorites }) {
  return <>
    {favorites.loading && <p className="gallery-feedback" role="status">Загружаем избранное…</p>}
    {favorites.error && <div className="gallery-feedback gallery-error" role="alert"><span>{favorites.error}</span><button type="button" onClick={() => void favorites.reload()}>Повторить</button></div>}
  </>;
}

function GalleryLightbox({ photos, photoId, onSelect, onClose, favorites }: {
  photos: GalleryPhoto[]; photoId: string; onSelect: (id: string) => void; onClose: () => void; favorites: Favorites;
}) {
  const titleId = useId(), content = useRef<HTMLDivElement>(null);
  const handlers = useRef({ onClose, move: (_direction: number) => {} });
  const index = Math.max(0, photos.findIndex(photo => photo.id === photoId)), photo = photos[index];
  handlers.current = { onClose, move: direction => { if (photos.length) onSelect(photos[(index + direction + photos.length) % photos.length].id); } };
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null, overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    content.current?.querySelector<HTMLButtonElement>(".gallery-close")?.focus();
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); handlers.current.onClose(); }
      if (event.key === "ArrowLeft") { event.preventDefault(); handlers.current.move(-1); }
      if (event.key === "ArrowRight") { event.preventDefault(); handlers.current.move(1); }
      if (event.key === "Tab") {
        const controls = Array.from(content.current?.querySelectorAll<HTMLButtonElement>("button:not(:disabled)") ?? []);
        const first = controls[0], last = controls.at(-1);
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = overflow; window.removeEventListener("keydown", keydown); if (previous?.isConnected) previous.focus(); };
  }, []);
  if (!photo) return null;
  return <div className="gallery-lightbox news-gallery-lightbox" role="dialog" aria-modal="true" aria-labelledby={titleId}>
    <button type="button" className="gallery-scrim" tabIndex={-1} onClick={onClose} aria-label="Закрыть галерею" />
    <div className="gallery-lightbox-content" ref={content}>
      <button type="button" className="gallery-close" onClick={onClose} aria-label="Закрыть галерею"><MaterialIcon name="x" size={20} /></button>
      <div className="gallery-lightbox-photo" role="img" aria-label={`${photo.title}. ${photo.date}`} style={{ backgroundImage: `url(${photo.src})`, backgroundPosition: photo.position ?? "center" }} />
      <div className="gallery-lightbox-caption">
        <div><strong id={titleId}>{photo.title}</strong><span>{photo.date}</span></div>
        <div className="gallery-lightbox-actions">
          <FavoriteButton photo={photo} favorites={favorites} />
          {photos.length > 1 && <><button type="button" onClick={() => handlers.current.move(-1)} aria-label="Предыдущее фото">←</button><span>{index + 1} / {photos.length}</span><button type="button" onClick={() => handlers.current.move(1)} aria-label="Следующее фото">→</button></>}
        </div>
      </div>
      <GalleryFeedback favorites={favorites} />
    </div>
  </div>;
}

export function CorporateGallery() {
  const favorites = useGalleryFavorites(), [selectedId, setSelectedId] = useState<string | null>(null);
  return <section className="card news-gallery-v2" id="bio-gallery" aria-label="Галерея корпоративных мероприятий BIO">
    <header><div><SectionIcon name="camera" /><h3 className="cabinet-block-heading">Галерея BIO</h3></div><button type="button" onClick={() => setSelectedId(galleryPhotos[0].id)}>Все фотографии →</button></header>
    <GalleryFeedback favorites={favorites} />
    <PublishedNews albums />
    <div className="news-gallery-grid">{galleryPhotos.map((photo, index) => <PhotoCard key={photo.id} photo={photo} featured={index === 0} favorites={favorites} onOpen={() => setSelectedId(photo.id)} />)}</div>
    {selectedId && <GalleryLightbox photos={galleryPhotos} photoId={selectedId} onSelect={setSelectedId} onClose={() => setSelectedId(null)} favorites={favorites} />}
  </section>;
}

export function EmployeeGallery({ onBrowse }: { onBrowse: () => void }) {
  const favorites = useGalleryFavorites(), [selectedId, setSelectedId] = useState<string | null>(null);
  const photos = galleryPhotos.filter(photo => favorites.photoIds.has(photo.id));
  return <section className="employee-photo-gallery compact-employee-gallery card personal-favorite-gallery" aria-label="Моя галерея">
    <header className="employee-photo-gallery-head"><div><SectionIcon name="camera" /><h3 className="cabinet-block-heading">Моя галерея</h3></div><div><button type="button" onClick={onBrowse}>Галерея BIO →</button></div></header>
    <GalleryFeedback favorites={favorites} />
    {favorites.ready && photos.length > 0 && <div className="personal-favorites-grid">{photos.map(photo => <PhotoCard key={photo.id} photo={photo} favorites={favorites} onOpen={() => setSelectedId(photo.id)} />)}</div>}
    {favorites.ready && photos.length === 0 && <div className="gallery-empty"><strong>Здесь будут ваши избранные фотографии</strong><p>Отметьте звездой понравившиеся снимки в Галерее BIO.</p><button type="button" className="button secondary" onClick={onBrowse}>Выбрать фотографии</button></div>}
    {selectedId && photos.length > 0 && <GalleryLightbox photos={photos} photoId={selectedId} onSelect={setSelectedId} onClose={() => setSelectedId(null)} favorites={favorites} />}
  </section>;
}
