"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { requestJson } from "./portal-ux";

type FavoriteChange = { photoId: string; favorite: boolean };
const eventName = "bio:gallery-favorites-changed";
const applyChange = (current: Set<string>, change: FavoriteChange) => {
  const next = new Set(current);
  if (change.favorite) next.add(change.photoId); else next.delete(change.photoId);
  return next;
};

export function useGalleryFavorites() {
  const [photoIds, setPhotoIds] = useState<Set<string>>(() => new Set());
  const [pendingIds, setPendingIds] = useState<Set<string>>(() => new Set());
  const [ready, setReady] = useState(false), [loading, setLoading] = useState(true), [error, setError] = useState("");
  const controller = useRef<AbortController | null>(null), revision = useRef(0), active = useRef(true), pending = useRef(new Set<string>());
  const reload = useCallback(async () => {
    controller.current?.abort();
    const current = new AbortController(), startedAt = revision.current;
    controller.current = current; setLoading(true);
    try {
      const data = await requestJson<{ photoIds: string[] }>("/api/gallery/favorites", { signal: current.signal });
      if (!current.signal.aborted && active.current && startedAt === revision.current) {
        setPhotoIds(new Set(data.photoIds)); setReady(true); setError("");
      }
    } catch (error) {
      if (!current.signal.aborted && active.current) setError(error instanceof Error ? error.message : "Не удалось загрузить избранное.");
    } finally { if (!current.signal.aborted && active.current) setLoading(false); }
  }, []);
  useEffect(() => {
    active.current = true; void reload();
    const changed = (event: Event) => {
      revision.current++;
      setPhotoIds(current => applyChange(current, (event as CustomEvent<FavoriteChange>).detail));
    };
    const refresh = () => void reload();
    window.addEventListener(eventName, changed); window.addEventListener("focus", refresh);
    return () => { active.current = false; controller.current?.abort(); window.removeEventListener(eventName, changed); window.removeEventListener("focus", refresh); };
  }, [reload]);
  const setFavorite = async (photoId: string, favorite: boolean) => {
    if (!ready || pending.current.has(photoId)) return;
    pending.current.add(photoId); revision.current++;
    setPendingIds(new Set(pending.current)); setError("");
    try {
      const saved = await requestJson<FavoriteChange>("/api/gallery/favorites", {
        method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ photoId, favorite }),
      });
      if (active.current) {
        setPhotoIds(current => applyChange(current, saved));
        window.dispatchEvent(new CustomEvent<FavoriteChange>(eventName, { detail: saved }));
      }
    } catch (error) {
      if (active.current) setError(error instanceof Error ? error.message : "Не удалось сохранить избранное.");
    } finally {
      pending.current.delete(photoId);
      if (active.current) setPendingIds(new Set(pending.current));
    }
  };
  return { photoIds, pendingIds, ready, loading, error, reload, setFavorite };
}
