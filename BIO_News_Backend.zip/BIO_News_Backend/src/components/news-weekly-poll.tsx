"use client";
import { useEffect, useRef, useState } from "react";
import { weeklyPoll, type WeeklyPollResult } from "../lib/news-weekly-poll";
import { SectionIcon } from "./section-icon";

export function NewsWeeklyPoll({ embedded = false }: { embedded?: boolean }) {
  const [open, setOpen] = useState(false), closeButton = useRef<HTMLButtonElement>(null);
  const [data, setData] = useState<WeeklyPollResult | null>(null), [choice, setChoice] = useState(""), [editing, setEditing] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(""), [notice, setNotice] = useState("");
  const load = async () => {
    setError(""); setBusy(true);
    try { const response = await fetch("/api/news/weekly-poll", { cache: "no-store" }), value = await response.json(); if (!response.ok) throw new Error(value.error?.message || "Опрос недоступен."); setData(value); setChoice(value.selected ?? ""); }
    catch (e) { setError(e instanceof Error ? e.message : "Опрос недоступен."); }
    finally { setBusy(false); }
  };
  useEffect(() => { void load(); }, []);
  const vote = async () => {
    if (!choice || busy) return;
    setBusy(true); setError(""); setNotice("");
    try {
      const response = await fetch("/api/news/weekly-poll", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ optionId: choice }) }), value = await response.json();
      if (!response.ok) throw new Error(value.error?.message || "Ответ не сохранён.");
      setData(value); setEditing(false); setNotice("Спасибо! Ваш ответ сохранён.");
    } catch (e) { setError(e instanceof Error ? e.message : "Ответ не сохранён."); }
    finally { setBusy(false); }
  };
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null, overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden"; closeButton.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") { setOpen(false); void load(); }
      if (e.key === "Tab") {
        const dialog = document.getElementById("news-poll-dialog"), controls = Array.from(dialog?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),[tabindex="0"]') ?? []), first = controls[0], last = controls.at(-1);
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener("keydown", key);
    return () => { document.body.style.overflow = overflow; document.removeEventListener("keydown", key); previous?.focus(); };
  }, [open]);
  if (embedded) return <>
    <button className="news-story-small news-poll-story-entry" onClick={() => setOpen(true)}>
      <span className="news-story-image news-poll-illustration" aria-hidden="true"><svg viewBox="0 0 64 64" width="64" height="64" fill="none" stroke="currentColor" strokeWidth="3"><path d="M10 52h44M17 45V30h7v15M29 45V21h7v24M41 45V12h7v33" /></svg></span>
      <span className="news-pills"><i>Опрос недели</i><i>Команда</i></span><h3>{weeklyPoll.question}</h3><p>Поделитесь мнением о следующем корпоративе.</p><footer><span>{data ? `Ответов: ${data.total}` : "Опрос"}</span><b>{data?.selected ? "Результаты →" : "Проголосовать →"}</b></footer>
    </button>
    {open && <div className="news-poll-dialog-overlay" onClick={e => { if (e.target === e.currentTarget) { setOpen(false); void load(); } }}><section id="news-poll-dialog" role="dialog" aria-modal="true" aria-labelledby="news-weekly-poll-heading" className="news-poll-dialog"><button className="news-cms-close" ref={closeButton} aria-label="Закрыть опрос" onClick={() => { setOpen(false); void load(); }}>×</button><NewsWeeklyPoll /></section></div>}
  </>;
  const showResults = !!data?.selected && !editing;
  return <section className={`card news-weekly-poll${embedded ? " news-poll-story" : ""}`} aria-labelledby="news-weekly-poll-heading">
    <header className="news-weekly-poll-header"><div className="news-section-title"><SectionIcon name="list" /><h3 className="cabinet-block-heading" id="news-weekly-poll-heading">Опрос недели</h3></div><span>{data ? `Ответов: ${data.total}` : ""}</span></header>
    <div className="news-weekly-poll-layout"><div className="news-weekly-poll-intro"><h4>{weeklyPoll.question}</h4><p>{showResults ? "Ваш ответ учтён" : "Выберите один вариант ответа"}</p></div>
      <div className="news-weekly-poll-content">
        {showResults ? <>
          <ul className="news-weekly-poll-results" aria-label="Результаты опроса">{data.options.map(option => <li key={option.id} className={data.selected === option.id ? "is-selected" : ""}><span className="news-weekly-poll-bar" style={{ width: `${option.percentage}%` }} /><span className="news-weekly-poll-result-text"><strong>{option.label}{data.selected === option.id && <small> · ваш ответ</small>}</strong><span>{option.count}<b>{option.percentage.toLocaleString("ru-RU")}%</b></span></span></li>)}</ul>
          <button className="news-weekly-poll-revote" disabled={busy} onClick={() => { setEditing(true); setNotice(""); }}>Переголосовать</button>
        </> : <form onSubmit={e => { e.preventDefault(); void vote(); }}>
          <fieldset disabled={!data || busy}><legend className="sr-only">Варианты ответа</legend>{weeklyPoll.options.map(option => <label className={choice === option.id ? "is-selected" : ""} key={option.id}><input type="radio" name="news-weekly-poll" value={option.id} checked={choice === option.id} onChange={() => setChoice(option.id)} /><span>{option.label}</span></label>)}</fieldset>
          <div className="news-weekly-poll-actions"><button className="button primary" disabled={!data || !choice || busy}>{busy ? "Загрузка…" : "Проголосовать"}</button>{editing && <button type="button" disabled={busy} onClick={() => { setEditing(false); setChoice(data?.selected ?? ""); }}>Отмена</button>}</div>
        </form>}
        {error && <p className="news-weekly-poll-error" role="alert">{error}{!data && <button onClick={() => void load()}>Повторить</button>}</p>}
        <span className="news-weekly-poll-notice" role="status">{notice}</span>
      </div>
    </div>
  </section>;
}
