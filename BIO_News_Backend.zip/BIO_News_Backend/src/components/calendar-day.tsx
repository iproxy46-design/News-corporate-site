"use client";

import { useEffect, useId, useState } from "react";
import { createPortal } from "react-dom";

type CalendarDayProps = {
  day: number;
  label: string;
  className: string;
  event?: { title: string; meta: string };
  eventContext?: string;
  onSelect: () => void;
};

export function CalendarDay({ day, label, className, event, eventContext = "Вы участвуете", onSelect }: CalendarDayProps) {
  const tooltipId = useId();
  const [anchor, setAnchor] = useState<{ left: number; top: number; below: boolean } | null>(null);
  const show = (target: HTMLButtonElement) => {
    if (!event) return;
    const bounds = target.getBoundingClientRect();
    const width = Math.min(320, window.innerWidth - 24);
    const below = bounds.top < 180;
    setAnchor({
      left: Math.max(12, Math.min(bounds.left + bounds.width / 2 - width / 2, window.innerWidth - width - 12)),
      top: below ? bounds.bottom + 8 : bounds.top - 8,
      below,
    });
  };
  useEffect(() => {
    if (!anchor) return;
    const hide = () => setAnchor(null);
    window.addEventListener("scroll", hide, { capture: true, passive: true });
    window.addEventListener("resize", hide);
    return () => { window.removeEventListener("scroll", hide, true); window.removeEventListener("resize", hide); };
  }, [anchor]);

  return <>
    <button
      type="button"
      className={className}
      aria-label={label}
      aria-describedby={anchor && event ? tooltipId : undefined}
      onPointerEnter={(e) => show(e.currentTarget)}
      onPointerLeave={() => setAnchor(null)}
      onFocus={(e) => show(e.currentTarget)}
      onBlur={() => setAnchor(null)}
      onKeyDown={(e) => { if (e.key === "Escape") setAnchor(null); }}
      onClick={() => { setAnchor(null); if (event) onSelect(); }}
    ><b>{day}</b></button>
    {anchor && event && createPortal(
      <div
        className="employee-calendar-tooltip"
        id={tooltipId}
        role="tooltip"
        style={{ left: anchor.left, top: anchor.top, transform: anchor.below ? undefined : "translateY(-100%)" }}
      >
        <small>{eventContext}</small>
        <strong>{event.title}</strong>
        <span>{event.meta}</span>
      </div>, document.body,
    )}
  </>;
}
