import { MaterialIcon } from "./material-icon";

export function SectionIcon({ name }: { name: "news" | "balloon" | "person" | "list" | "camera" }) {
  const shape = name === "news" || name === "camera" ? <MaterialIcon name={name === "news" ? "feed" : "camera"} size={20} /> :
    <svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
      {name === "balloon" ? <><ellipse cx="12" cy="8" rx="6" ry="7" /><path d="m12 15-1.5 2h3L12 15Zm0 2c3 3-3 3 0 6M9 5c-.7.6-1 1.5-1 2.5" /></> :
       name === "person" ? <><circle cx="12" cy="7" r="3.5" /><path d="M5 21v-2a7 7 0 0 1 14 0v2Z" /></> :
       <><path d="M9 6h12M9 12h12M9 18h12" /><circle cx="4" cy="6" r=".8" /><circle cx="4" cy="12" r=".8" /><circle cx="4" cy="18" r=".8" /></>}
    </svg>;
  return <span className="news-section-icon" aria-hidden="true">{shape}</span>;
}
