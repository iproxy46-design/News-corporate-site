"use client";
import { Fragment, useEffect, useMemo, useRef, useState } from "react";

import { MaterialIcon as Icon, type MaterialIconName as IconName } from "../components/material-icon";

import { EmployeePortrait } from "../components/employee-portrait";

import { CalendarDay } from "../components/calendar-day";

import { employeeCalendarEvents, corporateCalendarEvents } from "../lib/calendar-events";

import { NewsBirthdays, NewsViews } from "../components/news-birthdays";

import { NewsWeeklyPoll } from "../components/news-weekly-poll";

import { vacancyResumeMailto } from "../lib/vacancy-application";

import { SectionIcon } from "../components/section-icon";

import { CorporateGallery } from "../components/gallery";

import { PublishedNews } from "../components/news-publishing";

import { PortalDialog, type PortalNavigate } from "../components/portal-ux";

const companyNews = [
  {
    id: 0,
    category: "Дни рождения",
    tone: "birthday",
    author: "Команда BIO",
    initials: "МП",
    time: "Сегодня",
    title: "Сегодня день рождения у Марии Петровой",
    text: "Мария, специалист отдела маркетинга, сегодня принимает поздравления. Пожелаем ей ярких проектов, вдохновения и прекрасного года!",
    likes: 58,
    comments: 21,
    birthday: true,
  },
  {
    id: 7,
    category: "Объявление",
    tone: "announcement",
    author: "Администрация BIO",
    initials: "BIO",
    time: "Сегодня · 11:30",
    title: "Обновление пропускного режима с 17 августа",
    text: "Ознакомьтесь с новым порядком оформления гостевых пропусков и доступа на территорию офиса.",
    likes: 19,
    comments: 3,
    birthday: false,
  },
  {
    id: 1,
    category: "Компания",
    tone: "yellow",
    author: "BIO",
    initials: "BIO",
    time: "Сегодня · 10:15",
    title: "Открываем месяц клиентского сервиса",
    text: "В августе собираем лучшие практики команд и идеи, которые помогут сделать путь клиента ещё удобнее. Делитесь кейсами в комментариях.",
    likes: 42,
    comments: 8,
    birthday: false,
  },
  {
    id: 2,
    category: "Логистика",
    tone: "blue",
    author: "Складской комплекс",
    initials: "СК",
    time: "Сегодня · 09:20",
    title: "Новый рекорд комплектации заказов",
    text: "Команда Домодедово обработала 1 280 строк за смену без потери качества. Спасибо коллегам склада и логистики!",
    likes: 67,
    comments: 12,
    birthday: false,
  },
  {
    id: 3,
    category: "Персонал",
    tone: "purple",
    author: "Команда HR",
    initials: "HR",
    time: "Вчера · 17:40",
    title: "Добро пожаловать в BIO!",
    text: "К нам присоединились пять новых коллег. Их профили и планы адаптации уже доступны в разделе «Сотрудники».",
    likes: 35,
    comments: 9,
    birthday: false,
  },
  {
    id: 4,
    category: "Обучение",
    tone: "green",
    author: "Обучение и развитие",
    initials: "L&D",
    time: "Вчера · 14:10",
    title: "Стартовал курс по коммерческим переговорам",
    text: "Новый практический курс открыт для отделов закупок и продаж. Обучение можно проходить в удобном темпе до 24 августа.",
    likes: 24,
    comments: 5,
    birthday: false,
  },
  {
    id: 5,
    category: "Закупки",
    tone: "orange",
    author: "Импортные закупки",
    initials: "ИЗ",
    time: "6 августа · 16:25",
    title: "Расширяем пул поставщиков",
    text: "Завершён первый этап квалификации партнёров по новой категории оборудования. Следующий шаг — тестовые поставки.",
    likes: 31,
    comments: 11,
    birthday: false,
  },
  {
    id: 6,
    category: "Кофе",
    tone: "coffee",
    author: "Кофейное направление",
    initials: "CO",
    time: "6 августа · 11:00",
    title: "Демонстрационная зона обновлена",
    text: "В московском офисе появилась новая линейка кофейного оборудования. Записывайтесь на внутреннюю дегустацию.",
    likes: 53,
    comments: 16,
    birthday: false,
  },
];

const currentEmployee = {
  name: "Ирина Марухленко",
  firstName: "Ирина",
  birthday: "08-07",
  isNewEmployee: false,
  isMentor: false,
};

type CalendarEventDetail = {
  title: string;
  meta: string;
  description: string;
  participants: string[];
  organizer: string;
  tone?: string;
};

function CalendarEventDetailsModal({
  event,
  onClose,
  onToast,
  alreadyAdded = false,
  hideCalendarAction = false,
}: {
  event: CalendarEventDetail;
  onClose: () => void;
  onToast: (message: string) => void;
  alreadyAdded?: boolean;
  hideCalendarAction?: boolean;
}) {
  return (
    <div
      className="modal-overlay detail-overlay calendar-event-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="calendar-event-title"
    >
      <button
        className="modal-scrim"
        onClick={onClose}
        aria-label="Закрыть подробности события"
      />
      <section className="portal-detail-modal calendar-event-modal">
        <header>
          <div>
            <span>
              <Icon name="calendar" size={20} />
            </span>
            <p>
              <small>
                {alreadyAdded ? "Вы приглашены" : "Событие компании"}
              </small>
              <strong id="calendar-event-title">{event.title}</strong>
            </p>
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Закрыть"
          >
            <Icon name="x" size={19} />
          </button>
        </header>
        <div className="calendar-event-meta">
          <span>
            <Icon name="clock" size={17} />
            <p>
              <small>Дата, время и место</small>
              <strong>{event.meta}</strong>
            </p>
          </span>
          <span>
            <Icon name="people" size={17} />
            <p>
              <small>Организатор</small>
              <strong>{event.organizer}</strong>
            </p>
          </span>
        </div>
        <section className="calendar-event-description">
          <small>Описание события</small>
          <p>{event.description}</p>
        </section>
        {!hideCalendarAction && <section className="calendar-event-participants">
          <header>
            <div>
              <small>Участники</small>
              <strong>{event.participants.length} приглашённых</strong>
            </div>
            <span>
              {alreadyAdded ? "Ваш ответ: принято" : "Доступно сотрудникам BIO"}
            </span>
          </header>
          <div>
            {event.participants.map((person) => (
              <span key={person}>
                <i>
                  {person
                    .split(/\s+/)
                    .slice(0, 2)
                    .map((word) => word[0])
                    .join("")}
                </i>
                <strong>{person}</strong>
                <small>
                  {person === "Ирина Марухленко" ? "Вы" : "Участник"}
                </small>
              </span>
            ))}
          </div>
        </section>}
        <footer>
          <button className="button secondary" onClick={onClose}>
            Закрыть
          </button>
          {!hideCalendarAction && <button
            className="button primary"
            onClick={() => {
              onToast(
                alreadyAdded
                  ? `Открываем событие «${event.title}» в календаре`
                  : `Событие «${event.title}» добавлено в мой календарь`,
              );
              onClose();
            }}
          >
            <Icon name={alreadyAdded ? "calendar" : "plus"} size={15} />
            {alreadyAdded ? "Открыть в календаре" : "Добавить в мой календарь"}
          </button>}
        </footer>
      </section>
    </div>
  );
}

function WorkspaceEventsCalendar({
  onToast,
  corporateEvents,
}: {
  onToast: (message: string) => void;
  corporateEvents?: Record<string, CalendarEventDetail>;
}) {
  const [visibleMonth, setVisibleMonth] = useState(() => new Date(2026, 7, 1));
  const [selectedEvent, setSelectedEvent] =
    useState<CalendarEventDetail | null>(null);
  const scheduledEvents: Record<string, CalendarEventDetail> = {
    "2026-07-28": {
      title: "Итоги второго квартала",
      meta: "28 июля · 14:00 · Teams",
      tone: "meeting",
      organizer: "Финансовый отдел",
      description:
        "Подведение итогов квартала: выполнение плана, ключевые результаты команд и приоритеты следующего периода.",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Алексей Соколов",
        "Марина Крылова",
      ],
    },
    "2026-08-10": {
      title: "Общая встреча BIO",
      meta: "10 августа · 15:00 · Teams",
      tone: "meeting",
      organizer: "Команда BIO",
      description:
        "Открытая встреча для сотрудников: итоги месяца, приоритеты компании, новости подразделений и ответы руководителей на вопросы.",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Алексей Соколов",
        "Мария Петрова",
        "Дмитрий Романов",
      ],
    },
    "2026-08-12": {
      title: "Новинки Carboma",
      meta: "12 августа · 11:00 · шоурум",
      tone: "learning",
      organizer: "Продуктовая команда",
      description:
        "Демонстрация новой линейки Carboma, обзор ключевых характеристик и рекомендации для работы с дилерами.",
      participants: [
        "Ирина Марухленко",
        "Алексей Воронцов",
        "Марина Крылова",
        "Олег Кузнецов",
      ],
    },
    "2026-08-21": {
      title: "Встреча с поставщиком",
      meta: "21 августа · 10:30 · переговорная «Идея»",
      tone: "personal",
      organizer: "Ирина Марухленко",
      description:
        "Согласование сроков поставки, коммерческих условий и плана запуска новой товарной категории.",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Алексей Воронцов",
        "Сергей Панов",
      ],
    },
    "2026-09-03": {
      title: "Клуб переговорщиков",
      meta: "3 сентября · 16:30 · переговорная «Идея»",
      tone: "learning",
      organizer: "Университет BIO",
      description:
        "Практическая встреча клуба: разбор сложных переговорных кейсов и обмен рабочими приёмами.",
      participants: [
        "Ирина Марухленко",
        "Марина Крылова",
        "Алексей Воронцов",
        "Дмитрий Соколов",
      ],
    },
    "2026-09-17": {
      title: "Планирование поставок",
      meta: "17 сентября · 10:00 · Teams",
      tone: "personal",
      organizer: "Отдел импортных закупок",
      description:
        "Совместная сверка прогноза, сроков производства и логистических ограничений на следующий месяц.",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Марина Крылова",
        "Сергей Панов",
      ],
    },
  };
  const events = corporateEvents ?? employeeCalendarEvents(scheduledEvents, currentEmployee.name);
  const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Moscow", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const monthLabel = new Intl.DateTimeFormat("ru-RU", {
    month: "long",
    year: "numeric",
  }).format(visibleMonth);
  const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = [
    ...Array.from({ length: firstWeekday }, () => null),
    ...Array.from({ length: daysInMonth }, (_, index) => index + 1),
  ];
  const monthKey = `${year}-${String(month + 1).padStart(2, "0")}`;
  const eventCount = Object.keys(events).filter((key) =>
    key.startsWith(monthKey),
  ).length;
  const moveMonth = (direction: -1 | 1) =>
    setVisibleMonth(
      (current) =>
        new Date(current.getFullYear(), current.getMonth() + direction, 1),
    );
  return (
    <>
      <section
        className="workspace-calendar personal-invites-calendar"
        aria-label={corporateEvents ? "Корпоративный календарь BIO" : "Календарь событий, куда приглашена Ирина"}
      >
        <div className="workspace-calendar-head">
          <div>
            <span>
              <Icon name="calendar" size={16} />
            </span>
            <p>
              <strong>{corporateEvents ? "Календарь событий" : "Мой календарь"}</strong>
              <small>
                {monthLabel} · {eventCount}{" "}
                {eventCount === 1
                  ? "событие"
                  : eventCount > 1 && eventCount < 5
                    ? "события"
                    : "событий"}
              </small>
            </p>
          </div>
          <div className="workspace-calendar-nav">
            <button aria-label="Предыдущий месяц" onClick={() => moveMonth(-1)}>
              ‹
            </button>
            <button aria-label="Следующий месяц" onClick={() => moveMonth(1)}>
              ›
            </button>
          </div>
        </div>
        <div className="workspace-calendar-weekdays" aria-hidden="true">
          {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((day) => (
            <span key={day}>{day}</span>
          ))}
        </div>
        <div className="workspace-calendar-days">
          {days.map((day, index) => {
            const dateKey = day
              ? `${monthKey}-${String(day).padStart(2, "0")}`
              : "";
            const event = day ? events[dateKey] : undefined;
            const eventLabel = event ? `${event.title} · ${event.meta}` : "";
            const isToday = dateKey === today;
            return day ? (
              <CalendarDay
                key={day}
                day={day}
                event={event}
                eventContext={corporateEvents ? "Корпоративное событие" : "Вы участвуете"}
                className={`${isToday ? "today" : ""} ${event ? `has-event event-${event.tone}` : ""}`}
                label={
                  event
                    ? `${day}, ${monthLabel}: ${eventLabel}. Открыть подробности`
                    : `${day}, ${monthLabel}`
                }
                onSelect={() => event && setSelectedEvent(event)}
              />
            ) : (
              <span
                className="calendar-empty-day"
                key={`empty-${index}`}
                aria-hidden="true"
              />
            );
          })}
        </div>
      </section>
      {selectedEvent && (
        <CalendarEventDetailsModal
          event={selectedEvent}
          alreadyAdded={!corporateEvents}
          hideCalendarAction={Boolean(corporateEvents)}
          onClose={() => setSelectedEvent(null)}
          onToast={onToast}
        />
      )}
    </>
  );
}

type EmployeeProfileData = {
  initials: string;
  name: string;
  role: string;
  department: string;
  phone: string;
  email: string;
  location: string;
  online: boolean;
  status: string;
  statusTone: "online" | "away" | "offline";
  skills: string[];
  manager: string;
  photo?: string;
  position?: string;
};

const directoryEmployeeProfiles: EmployeeProfileData[] = [
    {
      initials: "ИМ",
      name: "Ирина Марухленко",
      role: "Ведущий менеджер по закупкам",
      department: "Импортные закупки",
      phone: "+7 495 120-42-18 · доб. 214",
      email: "i.marukhlenko@holdingbio.ru",
      location: "Москва",
      online: true,
      status: "В командировке до 15 августа",
      statusTone: "away",
      skills: [
        "Импортные закупки",
        "Переговоры",
        "Аналитика 1С",
        "Планирование поставок",
      ],
      manager: "Анна Смирнова",
      photo: "/bio-event-irina-1.webp",
      position: "50% 28%",
    },
    {
      initials: "АС",
      name: "Анна Смирнова",
      role: "Директор по закупкам",
      department: "Закупки",
      phone: "+7 495 120-42-18 · доб. 201",
      email: "a.smirnova@holdingbio.ru",
      location: "Москва",
      online: true,
      status: "На связи",
      statusTone: "online",
      skills: ["Стратегия закупок", "Управление командой", "Переговоры"],
      manager: "Генеральный директор",
      photo: "/bio-event-irina-2.webp",
      position: "62% 35%",
    },
    {
      initials: "АС",
      name: "Алексей Соколов",
      role: "Коммерческий директор",
      department: "Коммерческий блок",
      phone: "+7 495 120-42-18 · доб. 108",
      email: "a.sokolov@holdingbio.ru",
      location: "Москва",
      online: true,
      status: "На связи",
      statusTone: "online",
      skills: ["B2B-продажи", "Ключевые клиенты", "Коммерческая стратегия"],
      manager: "Генеральный директор",
      photo: "/gallery/bio-pirate-night-team.jpg",
      position: "22% 40%",
    },
    {
      initials: "АВ",
      name: "Анастасия Воронцова",
      role: "Менеджер по закупкам",
      department: "Импортные закупки",
      phone: "+7 495 120-42-18 · доб. 218",
      email: "a.vorontsova@holdingbio.ru",
      location: "Москва",
      online: false,
      status: "Вне сети",
      statusTone: "offline",
      skills: [
        "Работа с поставщиками",
        "Импортные поставки",
        "Английский язык",
      ],
      manager: "Ирина Марухленко",
      photo: "/bio-event-irina-2.webp",
      position: "62% 36%",
    },
    {
      initials: "МС",
      name: "Максим Сергеев",
      role: "Специалист складской логистики",
      department: "Логистика",
      phone: "+7 495 120-42-18 · доб. 327",
      email: "m.sergeev@holdingbio.ru",
      location: "Домодедово",
      online: true,
      status: "На связи",
      statusTone: "online",
      skills: ["Складская логистика", "Комплектация заказов", "1С:Склад"],
      manager: "Руководитель складского комплекса",
      photo: "/gallery/bio-pirate-night-team.jpg",
      position: "31% 39%",
    },
    {
      initials: "МП",
      name: "Мария Петрова",
      role: "HR-менеджер",
      department: "Отдел персонала",
      phone: "+7 495 120-42-18 · доб. 116",
      email: "m.petrova@holdingbio.ru",
      location: "Москва",
      online: false,
      status: "В отпуске до 18 августа",
      statusTone: "away",
      skills: ["Подбор персонала", "Адаптация", "Обучение сотрудников"],
      manager: "Директор по персоналу",
      photo: "/bio-event-irina-3.webp",
      position: "35% 30%",
    },
  ];

function EmployeeProfilePanel({
  person,
  onClose,
  onToast,
  onStartChat,
  onStartMail,
}: {
  person: EmployeeProfileData;
  onClose: () => void;
  onToast: (message: string) => void;
  onStartChat?: (name: string) => void;
  onStartMail?: (email: string) => void;
}) {
  const phoneHref = person.phone.split(" · ")[0].replace(/[^+\d]/g, "");
  return (
    <div
      className="panel-overlay employee-profile-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="employee-profile-title"
    >
      <button
        className="panel-scrim"
        onClick={onClose}
        aria-label="Закрыть профиль сотрудника"
      />
      <aside className="side-panel employee-profile-panel">
        <div className="panel-head">
          <div>
            <span className="eyebrow">Профиль сотрудника</span>
            <h2 id="employee-profile-title">{person.name}</h2>
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Закрыть"
          >
            <Icon name="x" />
          </button>
        </div>
        <div className="employee-profile-hero">
          <EmployeePortrait
            name={person.name}
            role={person.role}
            src={person.photo}
            initials={person.initials}
            position={person.position}
            online={person.online}
            headingLevel="h3"
          />
          <div>
            {person.status && <span className={`employee-profile-presence ${person.statusTone}`}>
              <i />
              {person.status}
            </span>}
            <small>
              {[person.department, person.location].filter(Boolean).join(" · ")}
            </small>
          </div>
        </div>
        {(person.email || person.phone) && <div className="employee-profile-contacts">
          {person.email && <a href={`mailto:${person.email}`}>
            <Icon name="mail" size={17} />
            <span>
              <small>Почта</small>
              <strong>{person.email}</strong>
            </span>
          </a>}
          {person.phone && <a href={`tel:${phoneHref}`}>
            <Icon name="phone" size={17} />
            <span>
              <small>Телефон</small>
              <strong>{person.phone}</strong>
            </span>
          </a>}
        </div>}
        {person.skills.length > 0 && <section className="employee-profile-section">
          <header>
            <span>
              <Icon name="target" size={17} />
            </span>
            <div>
              <small>Экспертиза</small>
              <strong>Чем может помочь коллега</strong>
            </div>
          </header>
          <div className="employee-profile-skills">
            {person.skills.map((skill) => (
              <button
                key={skill}
                onClick={() =>
                  onToast(`Ищем сотрудников с экспертизой «${skill}»`)
                }
              >
                {skill}
              </button>
            ))}
          </div>
        </section>}
        {person.manager && <section className="employee-profile-manager">
          <span>
            <Icon name="people" size={17} />
          </span>
          <p>
            <small>Руководитель</small>
            <strong>{person.manager}</strong>
          </p>
          <b>→</b>
        </section>}
        <footer className="employee-profile-actions">
          <button
            className="button secondary"
            onClick={() => {
              onClose();
              onStartChat
                ? onStartChat(person.name)
                : onToast(`Открываем чат: ${person.name}`);
            }}
          >
            <Icon name="chat" size={16} />
            Написать в чат
          </button>
          {person.email && <button
            className="button primary"
            onClick={() => {
              onClose();
              onStartMail
                ? onStartMail(person.email)
                : onToast(`Создаём письмо: ${person.email}`);
            }}
          >
            <Icon name="mail" size={16} />
            Написать письмо
          </button>}
        </footer>
      </aside>
    </div>
  );
}

function SuggestNewsModal({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (topic: string) => void;
}) {
  type Audience = "all" | "departments" | "employees";
  const departments = [
    "Импортные закупки",
    "Коммерческий отдел",
    "Логистика и склад",
    "Маркетинг",
    "Финансы",
    "Региональные продажи",
  ];
  const employees = [
    "Мария Петрова · Маркетинг",
    "Алексей Соколов · Логистика",
    "Елена Крылова · Финансы",
    "Анастасия Воронцова · Импортные закупки",
    "Максим Сергеев · Логистика",
  ];
  const [topic, setTopic] = useState("");
  const [description, setDescription] = useState("");
  const [sourceDepartment, setSourceDepartment] = useState("Импортные закупки");
  const [audience, setAudience] = useState<Audience>("all");
  const [selectedDepartments, setSelectedDepartments] = useState<Set<string>>(
    () => new Set(),
  );
  const [selectedEmployees, setSelectedEmployees] = useState<Set<string>>(
    () => new Set(),
  );
  const [employeeQuery, setEmployeeQuery] = useState("");
  const [imageName, setImageName] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const toggleSelection = (
    setter: React.Dispatch<React.SetStateAction<Set<string>>>,
    value: string,
  ) =>
    setter((current) => {
      const next = new Set(current);
      if (next.has(value)) next.delete(value);
      else next.add(value);
      return next;
    });
  const filteredEmployees = employees.filter((item) =>
    item.toLowerCase().includes(employeeQuery.trim().toLowerCase()),
  );
  const audienceReady =
    audience === "all" ||
    (audience === "departments" && selectedDepartments.size > 0) ||
    (audience === "employees" && selectedEmployees.size > 0);
  const canSubmit = Boolean(
    topic.trim() && description.trim() && audienceReady,
  );
  const improveWithAI = () => {
    setAiLoading(true);
    window.setTimeout(() => {
      if (!topic.trim()) setTopic("Новый результат команды BIO");
      setDescription(
        description.trim()
          ? `${description.trim()}\n\nПочему это важно: результат помогает командам BIO работать быстрее, делиться опытом и создавать лучший сервис для партнёров. Делитесь вопросами и идеями в комментариях.`
          : "Команда BIO делится важной новостью и практическим результатом. Расскажите коллегам, что изменилось, кому это поможет и какой следующий шаг стоит сделать. Добавьте факты, сроки и контакт ответственного сотрудника.",
      );
      setAiLoading(false);
    }, 650);
  };
  return (
    <div
      className="modal-overlay suggest-news-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="suggest-news-title"
    >
      <button
        className="modal-scrim"
        onClick={onClose}
        aria-label="Закрыть форму"
      />
      <form
        className="suggest-news-modal"
        onSubmit={(event) => {
          event.preventDefault();
          if (canSubmit) onSubmit(topic.trim());
        }}
      >
        <header className="suggest-news-head">
          <div>
            <span>
              <Icon name="feed" size={20} />
            </span>
            <div className="suggest-news-title-copy">
              <small>Корпоративная лента BIO</small>
              <h2 id="suggest-news-title">Предложить новость</h2>
            </div>
          </div>
          <button
            type="button"
            className="icon-button"
            onClick={onClose}
            aria-label="Закрыть"
          >
            <Icon name="x" size={20} />
          </button>
        </header>
        <div className="suggest-news-body">
          <label className="news-form-field">
            <span>
              Тема новости <b>*</b>
            </span>
            <input
              value={topic}
              onChange={(event) => setTopic(event.target.value)}
              placeholder="Например: новый рекорд команды логистики"
              autoFocus
            />
          </label>
          <label className="news-form-field">
            <span className="news-form-label-row">
              Описание <b>*</b>
              <button
                type="button"
                className="news-ai-edit"
                onClick={improveWithAI}
                disabled={aiLoading}
              >
                <Icon name="sparkles" size={15} />
                {aiLoading ? "ИИ редактирует…" : "Скорректировать с помощью ИИ"}
              </button>
            </span>
            <textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Расскажите, что произошло, почему это важно и что нужно знать коллегам"
              maxLength={1600}
            />
            <small>{description.length} / 1600</small>
          </label>
          <div className="news-form-row">
            <label className="news-form-field">
              <span>Подразделение-инициатор</span>
              <select
                value={sourceDepartment}
                onChange={(event) => setSourceDepartment(event.target.value)}
              >
                {departments.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
            <label
              className={`news-image-upload ${imageName ? "has-file" : ""}`}
            >
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(event) =>
                  setImageName(event.target.files?.[0]?.name ?? "")
                }
              />
              <span>
                <Icon name={imageName ? "check" : "file"} size={18} />
              </span>
              <p>
                <strong>{imageName || "Добавить изображение"}</strong>
                <small>
                  {imageName
                    ? "Изображение готово к загрузке"
                    : "PNG, JPG или WEBP · до 10 МБ"}
                </small>
              </p>
              <b>{imageName ? "Заменить" : "Выбрать"}</b>
            </label>
          </div>
          <fieldset className="news-audience-field">
            <legend>
              Кому доступна новость <b>*</b>
            </legend>
            <div
              className="news-audience-tabs"
              role="radiogroup"
              aria-label="Аудитория новости"
            >
              {[
                ["all", "Все сотрудники", "Вся компания"],
                [
                  "departments",
                  "Выбрать отделы",
                  "Одно или несколько подразделений",
                ],
                ["employees", "Выбрать сотрудников", "Персональная аудитория"],
              ].map(([id, label, hint]) => (
                <button
                  type="button"
                  key={id}
                  role="radio"
                  aria-checked={audience === id}
                  className={audience === id ? "active" : ""}
                  onClick={() => setAudience(id as Audience)}
                >
                  <i>{audience === id && <Icon name="check" size={12} />}</i>
                  <span>
                    <strong>{label}</strong>
                    <small>{hint}</small>
                  </span>
                </button>
              ))}
            </div>
            {audience === "departments" && (
              <div className="news-selector-grid">
                {departments.map((item) => (
                  <button
                    type="button"
                    key={item}
                    className={selectedDepartments.has(item) ? "selected" : ""}
                    onClick={() =>
                      toggleSelection(setSelectedDepartments, item)
                    }
                  >
                    <i>
                      {selectedDepartments.has(item) && (
                        <Icon name="check" size={11} />
                      )}
                    </i>
                    {item}
                  </button>
                ))}
              </div>
            )}
            {audience === "employees" && (
              <div className="employee-audience-picker">
                <label>
                  <Icon name="search" size={16} />
                  <input
                    value={employeeQuery}
                    onChange={(event) => setEmployeeQuery(event.target.value)}
                    placeholder="Найти сотрудника по имени или отделу"
                  />
                </label>
                <div>
                  {filteredEmployees.map((item) => (
                    <button
                      type="button"
                      key={item}
                      className={selectedEmployees.has(item) ? "selected" : ""}
                      onClick={() =>
                        toggleSelection(setSelectedEmployees, item)
                      }
                    >
                      <i>
                        {item
                          .split(" ")
                          .slice(0, 2)
                          .map((part) => part[0])
                          .join("")}
                      </i>
                      <span>{item}</span>
                      {selectedEmployees.has(item) && (
                        <Icon name="check" size={14} />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </fieldset>
        </div>
        <footer className="suggest-news-footer">
          <span>
            <Icon name="check" size={15} />
            После отправки новость поступит на согласование в отдел персонала
          </span>
          <div>
            <button
              type="button"
              className="button secondary"
              onClick={onClose}
            >
              Отмена
            </button>
            <button
              type="submit"
              className="button primary"
              disabled={!canSubmit}
            >
              Отправить в отдел персонала
            </button>
          </div>
        </footer>
      </form>
    </div>
  );
}

type NewsDetailItem = {
  id: string | number;
  category: string;
  tone: string;
  author: string;
  time: string;
  title: string;
  text: string;
  likes: number;
  comments: number;
  birthday: boolean;
};

type ArchivedNewsItem = NewsDetailItem & {
  initials?: string;
  month: string;
  dateLabel: string;
  image: string;
};

type VacancyDetailItem = {
  title: string;
  department: string;
  meta: string;
  hot?: boolean;
  purpose: string;
  responsibilities: string[];
  requirements: string[];
};

type NewcomerDetailItem = {
  initials: string;
  name: string;
  meta: string;
  date: string;
  photo: string;
  position: string;
  role: string;
  email: string;
  phone: string;
  manager: string;
  about: string;
};

function NewsDetailModal({
  item,
  onClose,
  onToast,
}: {
  item: NewsDetailItem;
  onClose: () => void;
  onToast: (message: string) => void;
}) {
  const isEvent = item.category === "Общее событие";
  const isAnnouncement = item.category === "Объявление";
  const isAi = item.category === "Обзор рынка";
  const image = isAi
    ? "/bio-logistics.png"
    : isEvent
      ? item.title.includes("Carboma")
        ? "/bio-event-irina-2.webp"
        : "/bio-event-irina-3.webp"
      : item.id === 2
        ? "/bio-logistics.png"
        : item.id === 3
          ? "/gallery/bio-pirate-night-team.jpg"
          : item.id === 4
            ? "/bio-about.png"
            : "/bio-event-irina-1.webp";
  return (
    <div
      className="modal-overlay detail-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="news-detail-title"
    >
      <button
        className="modal-scrim"
        onClick={onClose}
        aria-label="Закрыть новость"
      />
      <article className="portal-detail-modal news-detail-modal">
        <header className="detail-modal-head">
          <div>
            <i className={`feed-category ${item.tone}`}>{item.category}</i>
            <span>
              {item.author} · {item.time}
            </span>
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Закрыть"
          >
            <Icon name="x" size={20} />
          </button>
        </header>
        <div
          className="news-detail-cover"
          style={{
            backgroundImage: `linear-gradient(180deg,rgba(20,21,18,.03),rgba(20,21,18,.42)),url(${image})`,
          }}
        >
          <span>
            {isAi
              ? "ИИ-обзор · источники проверены"
              : isAnnouncement
                ? "Важно знать"
                : isEvent
                  ? "Событие BIO"
                  : "Лента BIO"}
          </span>
        </div>
        <div className="detail-modal-body">
          <h2 id="news-detail-title">{item.title}</h2>
          <p className="news-detail-lead">{item.text}</p>
          <p>
            {isAi
              ? "БИОсфера сравнила отраслевые публикации, исключила дубли и рекламные материалы. Черновик прошёл проверку и согласование перед публикацией в ленте BIO."
              : "Мы собрали подробности, контакты и следующий шаг в одной публикации. Информация доступна сотрудникам с учётом подразделения и прав доступа."}
          </p>
          {isAnnouncement ? (
            <div className="detail-info-box">
              <Icon name="alert" size={19} />
              <div>
                <strong>Важная информация</strong>
                <span>
                  Изменения и подробности приведены в этой новости.
                </span>
              </div>
            </div>
          ) : (
            <div className="news-detail-points">
              <div>
                <strong>{isAi ? "Источники" : "Что важно"}</strong>
                <span>
                  {isAi
                    ? "5 отраслевых публикаций · ссылки сохранены у редактора"
                    : "Результат помогает командам быстрее обмениваться опытом и поддерживать высокий уровень сервиса."}
                </span>
              </div>
              <div>
                <strong>{isAi ? "Проверка" : "Что дальше"}</strong>
                <span>
                  {isAi
                    ? "Факты и формулировки согласованы отделом персонала"
                    : "Откройте связанные материалы или задайте вопрос автору публикации в комментариях."}
                </span>
              </div>
            </div>
          )}
        </div>
        <footer className="detail-modal-footer">
          <div>
            <button
              onClick={() =>
                onToast(`Спасибо! Реакция добавлена к новости «${item.title}»`)
              }
            >
              ♥ {item.likes}
            </button>
            <button
              onClick={() => onToast(`Открываем ${item.comments} комментариев`)}
            >
              <Icon name="chat" size={15} />
              {item.comments} комментариев
            </button>
          </div>
          <button className={`button ${isAnnouncement ? "secondary" : "primary"}`} onClick={() => {
            if (!isAnnouncement) onToast("Новость сохранена в избранное");
            onClose();
          }}>{isAnnouncement ? "Закрыть" : "Сохранить новость"}</button>
        </footer>
      </article>
    </div>
  );
}

function NewsArchivePage({
  items,
  onBack,
  onOpen,
}: {
  items: ArchivedNewsItem[];
  onBack: () => void;
  onOpen: (item: NewsDetailItem) => void;
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Все темы");
  const normalizedQuery = query.trim().toLowerCase();
  const categories = [
    "Все темы",
    ...Array.from(new Set(items.map((item) => item.category))),
  ];
  const months = Array.from(new Set(items.map((item) => item.month)));
  const visibleItems = items.filter(
    (item) =>
      (category === "Все темы" || item.category === category) &&
      (!normalizedQuery ||
        `${item.title} ${item.text} ${item.author} ${item.category}`
          .toLowerCase()
          .includes(normalizedQuery)),
  );
  return (
    <section className="news-archive-page" aria-label="Архив новостей компании">
      <header className="news-archive-hero">
        <button className="news-archive-back" onClick={onBack}>
          <span>←</span>К ленте
        </button>
        <div>
          <span className="date-label">Корпоративная жизнь BIO</span>
          <h1>Все новости</h1>
          <p>
            Публикации компании собраны по месяцам — найдите нужную по теме или
            ключевому слову.
          </p>
        </div>
      </header>
      <section className="news-archive-tools card">
        <label>
          <Icon name="search" size={19} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Поиск по заголовку, тексту или автору"
            aria-label="Поиск по архиву новостей"
          />
          {query && (
            <button onClick={() => setQuery("")} aria-label="Очистить поиск">
              <Icon name="x" size={15} />
            </button>
          )}
        </label>
        <div
          className="news-archive-categories"
          role="list"
          aria-label="Темы новостей"
        >
          {categories.map((item) => (
            <button
              key={item}
              className={category === item ? "active" : ""}
              onClick={() => setCategory(item)}
            >
              {item}
            </button>
          ))}
        </div>
      </section>
      <div className="news-archive-summary">
        <span>
          {visibleItems.length}{" "}
          {visibleItems.length === 1
            ? "публикация"
            : visibleItems.length < 5
              ? "публикации"
              : "публикаций"}
        </span>
        <small>
          {normalizedQuery
            ? `По запросу «${query.trim()}»`
            : category === "Все темы"
              ? "Все темы"
              : category}
        </small>
      </div>
      {visibleItems.length ? (
        <div className="news-archive-months">
          {months.map((month) => {
            const monthItems = visibleItems.filter(
              (item) => item.month === month,
            );
            return monthItems.length ? (
              <section className="news-archive-month" key={month}>
                <header>
                  <div>
                    <h2>{month}</h2>
                    <span>{monthItems.length}</span>
                  </div>
                  <i />
                </header>
                <div>
                  {monthItems.map((item) => (
                    <button
                      className={
                        item.category === "Объявление" ? "important" : ""
                      }
                      key={item.id}
                      onClick={() => onOpen(item)}
                    >
                      <span
                        className="news-archive-image"
                        style={{
                          backgroundImage: `linear-gradient(180deg,rgba(18,19,16,.02),rgba(18,19,16,.16)),url(${item.image})`,
                        }}
                      >
                        {item.category === "Объявление" && <b>Важно</b>}
                      </span>
                      <div>
                        <small>
                          {item.dateLabel} · {item.author}
                        </small>
                        <em>#{item.category.toLowerCase()}</em>
                        <strong>{item.title}</strong>
                        <p>{item.text}</p>
                        <span>Читать новость →</span>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            ) : null;
          })}
        </div>
      ) : (
        <div className="news-archive-empty card">
          <span>
            <Icon name="search" size={25} />
          </span>
          <h2>Новости не найдены</h2>
          <p>Попробуйте изменить запрос или выбрать другую тему.</p>
          <button
            onClick={() => {
              setQuery("");
              setCategory("Все темы");
            }}
          >
            Сбросить фильтры
          </button>
        </div>
      )}
    </section>
  );
}

function VacancyDetailModal({ vacancy, onClose }: { vacancy: VacancyDetailItem; onClose: () => void }) {
  const hr = directoryEmployeeProfiles.find(person => person.department === "Отдел персонала");
  return <PortalDialog title={vacancy.title} onClose={onClose}><div className="ux-help"><p>{vacancy.department} · {vacancy.meta}</p><p>{vacancy.purpose}</p><h3>Задачи</h3><ul>{vacancy.responsibilities.map((value) => <li key={value}>{value}</li>)}</ul><h3>Требования</h3><ul>{vacancy.requirements.map((value) => <li key={value}>{value}</li>)}</ul>{hr?.email && <div className="vacancy-resume-action"><a className="button primary" href={vacancyResumeMailto(vacancy.title, hr.email)}>Отправить резюме в отдел персонала</a><small>Откроется письмо в почтовой программе. Прикрепите резюме перед отправкой.</small></div>}</div></PortalDialog>;
}

function NewcomerProfileModal({
  person,
  onClose,
  onMessage,
}: {
  person: NewcomerDetailItem;
  onClose: () => void;
  onMessage: () => void;
}) {
  return (
    <div
      className="modal-overlay detail-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="newcomer-profile-title"
    >
      <button
        className="modal-scrim"
        onClick={onClose}
        aria-label="Закрыть профиль"
      />
      <article className="portal-detail-modal newcomer-profile-modal">
        <header className="detail-modal-head">
          <div>
            <i className="feed-category green">Новый сотрудник</i>
            <span>{person.date}</span>
          </div>
          <button
            className="icon-button"
            onClick={onClose}
            aria-label="Закрыть"
          >
            <Icon name="x" size={20} />
          </button>
        </header>
        <div className="newcomer-profile-hero">
          <i
            style={{
              backgroundImage: `url(${person.photo})`,
              backgroundPosition: person.position,
            }}
          >
            {person.initials}
          </i>
          <div>
            <small>Добро пожаловать в BIO!</small>
            <h2 id="newcomer-profile-title">{person.name}</h2>
            <p>
              {person.role} · {person.meta}
            </p>
          </div>
        </div>
        <div className="detail-modal-body">
          <p className="newcomer-profile-about">{person.about}</p>
          <dl className="newcomer-profile-contacts">
            <div>
              <dt>Электронная почта</dt>
              <dd>{person.email}</dd>
            </div>
            <div>
              <dt>Телефон</dt>
              <dd>{person.phone}</dd>
            </div>
            <div>
              <dt>Руководитель</dt>
              <dd>{person.manager}</dd>
            </div>
            <div>
              <dt>Статус</dt>
              <dd>Проходит адаптацию</dd>
            </div>
          </dl>
          <div className="detail-info-box">
            <Icon name="sparkles" size={19} />
            <div>
              <strong>Пожелаем лёгкой адаптации</strong>
              <span>
                Поддержите нового коллегу — напишите приветственное сообщение
                или предложите помощь.
              </span>
            </div>
          </div>
        </div>
        <footer className="detail-modal-footer">
          <button className="button secondary" onClick={onClose}>
            Закрыть
          </button>
          <button className="button primary" onClick={onMessage}>
            <Icon name="chat" size={16} />
            Написать сотруднику
          </button>
        </footer>
      </article>
    </div>
  );
}

const portalVacancies: VacancyDetailItem[] = [
    {
      title: "Руководитель группы закупок",
      department: "Отдел импортных закупок",
      meta: "Москва · гибрид",
      hot: true,
      purpose:
        "Управлять закупочной категорией, развивать международных поставщиков и обеспечивать устойчивые условия поставок для бизнеса BIO.",
      responsibilities: [
        "Руководить командой закупок и распределять категории",
        "Проводить переговоры и оценивать поставщиков",
        "Контролировать сроки, бюджеты и риски поставок",
      ],
      requirements: [
        "Опыт в закупках от 4 лет",
        "Сильные навыки аналитики и переговоров",
        "Английский язык для деловой переписки",
      ],
    },
    {
      title: "Категорийный менеджер HoReCa",
      department: "Коммерческий отдел",
      meta: "Москва · офис BIO",
      purpose:
        "Развивать ассортимент профессионального оборудования HoReCa и формировать конкурентное предложение для дилеров и ключевых клиентов.",
      responsibilities: [
        "Управлять ассортиментом и жизненным циклом категории",
        "Анализировать рынок, продажи и маржинальность",
        "Готовить продуктовые запуски вместе с маркетингом",
      ],
      requirements: [
        "Опыт категорийного менеджмента",
        "Понимание рынка оборудования HoReCa",
        "Уверенная работа с Excel и аналитикой",
      ],
    },
    {
      title: "Менеджер по ключевым клиентам",
      department: "Отдел по работе с ключевыми клиентами",
      meta: "Домодедово · гибрид",
      purpose:
        "Развивать долгосрочное партнёрство с ключевыми клиентами BIO и создавать комплексные решения под задачи бизнеса.",
      responsibilities: [
        "Вести портфель ключевых клиентов",
        "Формировать коммерческие предложения",
        "Координировать проекты с закупками и логистикой",
      ],
      requirements: [
        "Опыт B2B-продаж от 2 лет",
        "Сильная клиентская ориентация",
        "Навыки презентации и ведения переговоров",
      ],
    },
  ];

function CorporateNewsDashboard({
  onToast,
  onNavigate,
  onStartChat,
}: {
  onToast: (message: string) => void;
  onNavigate: PortalNavigate;
  onStartChat: (name: string) => void;
}) {
  const motivationPhrases = [
    {
      quote:
        "Единственный способ делать великую работу — любить то, что вы делаете.",
      author: "Стив Джобс",
    },
    {
      quote: "Оставайтесь голодными. Оставайтесь безрассудными.",
      author: "Стив Джобс",
    },
    {
      quote:
        "Образование — самое мощное оружие, с помощью которого можно изменить мир.",
      author: "Нельсон Мандела",
    },
    {
      quote: "Поодиночке мы можем так мало; вместе мы можем так много.",
      author: "Хелен Келлер",
    },
    {
      quote:
        "Тот, кто доволен уже сделанным, становится препятствием на пути прогресса.",
      author: "Хелен Келлер",
    },
    {
      quote:
        "Продолжать попытки, несмотря на разочарования и неудачи, — единственный способ оставаться смелым.",
      author: "Хелен Келлер",
    },
    {
      quote:
        "Каждому из нас дана способность создавать и распространять счастье — и это лучшее, что мы можем делать.",
      author: "Хелен Келлер",
    },
    {
      quote: "Сделать для мира больше, чем мир делает для вас, — вот успех.",
      author: "Генри Форд",
    },
    {
      quote:
        "Передо мной словно открылся новый мир — мир науки, который я наконец могла познавать свободно.",
      author: "Мария Склодовская-Кюри",
    },
    {
      quote:
        "Силу, смелость и уверенность обретаешь в каждом опыте, когда действительно смотришь страху в лицо.",
      author: "Элеонора Рузвельт",
    },
    {
      quote: "Будущее принадлежит тем, кто верит в красоту своей мечты.",
      author: "Элеонора Рузвельт",
    },
    {
      quote: "Вы должны делать то, что, как вам кажется, вы не можете сделать.",
      author: "Элеонора Рузвельт",
    },
    {
      quote:
        "Цель жизни — быть счастливым. Мы живём надеждой, и именно она помогает нам двигаться вперёд.",
      author: "Далай-лама XIV",
    },
    {
      quote:
        "Нация должна верить в прошлое, в будущее и, прежде всего, в способность людей учиться на прошлом.",
      author: "Франклин Рузвельт",
    },
  ];
  const getDailyMotivation = () => {
    const now = new Date();
    const calendarDay = Math.floor(
      Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000,
    );
    return motivationPhrases[calendarDay % motivationPhrases.length];
  };
  
  const [query, setQuery] = useState("");
  const [activeTopic, setActiveTopic] = useState("Все");
  const [searchFocused, setSearchFocused] = useState(false);
  const [newsModalOpen, setNewsModalOpen] = useState(false);
  
  
  const [selectedNews, setSelectedNews] = useState<NewsDetailItem | null>(null);
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [selectedVacancy, setSelectedVacancy] =
    useState<VacancyDetailItem | null>(null);
  const [selectedBirthdayProfile, setSelectedBirthdayProfile] = useState<EmployeeProfileData | null>(null);
  const [selectedNewcomer, setSelectedNewcomer] =
    useState<NewcomerDetailItem | null>(null);
  const [dailyMotivation, setDailyMotivation] = useState(getDailyMotivation);
  
  
  useEffect(() => {
    const refreshMotivation = () => setDailyMotivation(getDailyMotivation());
    const timer = window.setInterval(refreshMotivation, 60000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    const openArchive = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest(".all-news-link")) return;
      event.preventDefault();
      event.stopPropagation();
      setArchiveOpen(true);
    };
    document.addEventListener("click", openArchive, true);
    return () => document.removeEventListener("click", openArchive, true);
  }, []);
  const events = [
    {
      date: "22",
      month: "июл",
      iso: "2026-07-22",
      title: "Летний клуб руководителей",
      meta: "22 июля · 14:00 · переговорная «Идея»",
      general: false,
      description:
        "Обмен практиками управления командами и итогами первого полугодия.",
      organizer: "Университет BIO",
      participants: [
        "Анна Смирнова",
        "Алексей Соколов",
        "Мария Петрова",
        "Ирина Марухленко",
      ],
    },
    {
      date: "10",
      month: "авг",
      iso: "2026-08-10",
      title: "Общая встреча BIO",
      meta: "10 августа · 15:00 · Teams",
      general: true,
      description:
        "Открытая встреча для всех сотрудников: итоги месяца, приоритеты и ответы на вопросы.",
      organizer: "Команда BIO",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Алексей Соколов",
        "Мария Петрова",
        "Дмитрий Романов",
      ],
    },
    {
      date: "12",
      month: "авг",
      iso: "2026-08-12",
      title: "Презентация новинок Carboma",
      meta: "12 августа · 11:00 · шоурум",
      general: true,
      description:
        "Общее событие компании с демонстрацией новой линейки оборудования и разбором преимуществ для клиентов HoReCa.",
      organizer: "Продуктовая команда",
      participants: [
        "Ирина Марухленко",
        "Алексей Воронцов",
        "Марина Крылова",
        "Олег Кузнецов",
      ],
    },
    {
      date: "18",
      month: "авг",
      iso: "2026-08-18",
      title: "Клуб переговорщиков",
      meta: "18 августа · 16:30 · переговорная «Идея»",
      general: false,
      description:
        "Встреча участников профессионального клуба по приглашению: практика аргументации и разбор кейсов.",
      organizer: "Университет BIO",
      participants: [
        "Ирина Марухленко",
        "Марина Крылова",
        "Дмитрий Соколов",
        "Сергей Панов",
      ],
    },
    {
      date: "03",
      month: "сен",
      iso: "2026-09-03",
      title: "Старт осенней программы обучения",
      meta: "3 сентября · 12:00 · Университет BIO",
      general: true,
      description: "Презентация курсов и траекторий развития на новый сезон.",
      organizer: "Команда обучения и развития",
      participants: [
        "Ирина Марухленко",
        "Анна Смирнова",
        "Мария Петрова",
        "Анастасия Воронцова",
      ],
    },
  ];
  const dailyPolls = [
    {
      question: "Что сильнее всего поможет ускорить согласование поставок?",
      source: "База знаний · Процесс согласования поставок",
      options: [
        "Единый чек-лист",
        "Автоматические напоминания",
        "Меньше этапов согласования",
      ],
    },
    {
      question: "Какой формат обмена опытом с поставщиками полезнее команде?",
      source: "База знаний · Работа с поставщиками",
      options: [
        "Короткие кейсы в ленте",
        "Ежемесячная встреча",
        "Подборка лучших практик",
      ],
    },
    {
      question:
        "Что помогает новому сотруднику быстрее почувствовать себя частью BIO?",
      source: "База знаний · Адаптация в компании",
      options: [
        "Встреча с командой",
        "Понятный план на месяц",
        "Поддержка наставника",
      ],
    },
    {
      question:
        "Какой навык больше всего влияет на отличный сервис для дилеров?",
      source: "База знаний · Стандарты клиентского сервиса",
      options: ["Скорость ответа", "Экспертиза по продукту", "Проактивность"],
    },
    {
      question: "Какую рабочую инструкцию стоит упростить в первую очередь?",
      source: "База знаний · Регламенты и процессы",
      options: ["Командировки", "Закупки и поставки", "Внутренние заявки"],
    },
  ];
  const dailyPoll =
    dailyPolls[(new Date().getUTCDate() - 1) % dailyPolls.length];
  
  const newcomers: NewcomerDetailItem[] = [
    {
      initials: "АВ",
      name: "Анастасия Воронцова",
      meta: "Импортные закупки · Москва",
      date: "С нами с 5 августа",
      photo: "/portraits/anastasia.png",
      position: "center 28%",
      role: "Менеджер по импортным закупкам",
      email: "a.vorontsova@holdingbio.ru",
      phone: "+7 495 120-42-18 · доб. 214",
      manager: "Ирина Марухленко",
      about:
        "Анастасия будет развивать работу с зарубежными поставщиками, координировать поставки и помогать команде находить лучшие условия сотрудничества.",
    },
    {
      initials: "МС",
      name: "Максим Сергеев",
      meta: "Логистика · Домодедово",
      date: "С нами с 8 августа",
      photo: "/portraits/maxim.png",
      position: "center 28%",
      role: "Специалист складской логистики",
      email: "m.sergeev@holdingbio.ru",
      phone: "+7 495 120-42-18 · доб. 327",
      manager: "Алексей Соколов",
      about:
        "Максим отвечает за точность складских операций, скорость комплектации и улучшение взаимодействия между складом и командами продаж.",
    },
    {
      initials: "ОД",
      name: "Ольга Демидова",
      meta: "Маркетинг · Москва",
      date: "С нами с 14 августа",
      photo: "/portraits/olga.png",
      position: "center 28%",
      role: "Ведущий специалист по маркетингу",
      email: "o.demidova@holdingbio.ru",
      phone: "+7 495 120-42-18 · доб. 246",
      manager: "Мария Петрова",
      about:
        "Ольга будет развивать продуктовые коммуникации, готовить материалы для дилеров и поддерживать запуски новых решений BIO.",
    },
    {
      initials: "ИК",
      name: "Илья Крылов",
      meta: "IT · Москва",
      date: "С нами с 19 августа",
      photo: "/portraits/ilya.png",
      position: "center 28%",
      role: "Системный аналитик",
      email: "i.krylov@holdingbio.ru",
      phone: "+7 495 120-42-18 · доб. 305",
      manager: "Дмитрий Романов",
      about:
        "Илья присоединился к команде развития портала и поможет переводить рабочие процессы сотрудников в удобные цифровые сервисы.",
    },
  ];
  const vacancies = portalVacancies;
  const regularNews = companyNews.filter((item) => !item.birthday);
  const generalEventNews = events
    .filter((item) => item.general)
    .map((item, index) => ({
      id: `event-${index}`,
      category: "Общее событие",
      tone: "event",
      author: "Календарь BIO",
      initials: "К",
      time: `${item.date} ${item.month} · ${item.meta}`,
      title: item.title,
      text: item.description,
      likes: 0,
      comments: 0,
      birthday: false,
    }));
  
  const pollNews = {
    id: "daily-poll",
    category: "Опрос дня",
    tone: "poll",
    author: "Отдел персонала · База знаний",
    initials: "ОП",
    time: "Сегодня · до 18:00",
    title: dailyPoll.question,
    text: "Ответьте прямо в ленте — результаты помогут улучшить рабочие процессы BIO.",
    likes: 0,
    comments: 0,
    birthday: false,
  };
  const newsStream = [
    regularNews[0],
    pollNews,
    regularNews[1],
    generalEventNews[0],
    regularNews[2],
    generalEventNews[1],
    ...regularNews.slice(3, 6),
  ].filter(Boolean);
  const historicalNews: ArchivedNewsItem[] = [
    {
      id: "jul-1",
      month: "Июль 2026",
      dateLabel: "28 июля",
      category: "Компания",
      tone: "yellow",
      author: "Команда BIO",
      initials: "BIO",
      time: "28 июля",
      title: "Команда BIO готовится к ПИР Экспо",
      text: "Начали подготовку стенда, продуктовых демонстраций и встреч с дилерами на главном отраслевом событии осени.",
      likes: 48,
      comments: 9,
      birthday: false,
      image: "/gallery/bio-pirate-night-team.jpg",
    },
    {
      id: "jul-2",
      month: "Июль 2026",
      dateLabel: "21 июля",
      category: "Закупки",
      tone: "orange",
      author: "Импортные закупки",
      initials: "ИЗ",
      time: "21 июля",
      title: "Обновлены правила квалификации поставщиков",
      text: "Новый чек-лист объединяет финансовую проверку, оценку качества и требования к стабильности поставок.",
      likes: 27,
      comments: 6,
      birthday: false,
      image: "/bio-logistics.png",
    },
    {
      id: "jul-3",
      month: "Июль 2026",
      dateLabel: "14 июля",
      category: "Обучение",
      tone: "green",
      author: "Университет BIO",
      initials: "L&D",
      time: "14 июля",
      title: "Открыта программа развития руководителей",
      text: "В программе — управление командой, обратная связь, постановка целей и практикумы по сложным управленческим ситуациям.",
      likes: 39,
      comments: 12,
      birthday: false,
      image: "/bio-about.png",
    },
    {
      id: "jul-4",
      month: "Июль 2026",
      dateLabel: "5 июля",
      category: "Персонал",
      tone: "purple",
      author: "Отдел персонала",
      initials: "HR",
      time: "5 июля",
      title: "Как прошёл семейный день BIO",
      text: "Собрали фотографии, тёплые отзывы и лучшие моменты летнего праздника для сотрудников и их семей.",
      likes: 86,
      comments: 24,
      birthday: false,
      image: "/gallery/bio-pirate-night-team.jpg",
    },
    {
      id: "jun-1",
      month: "Июнь 2026",
      dateLabel: "26 июня",
      category: "Кофе",
      tone: "coffee",
      author: "Кофейное направление",
      initials: "CO",
      time: "26 июня",
      title: "Новая демонстрационная зона открыта для встреч",
      text: "В московском офисе можно проводить презентации кофейного оборудования и тестирование решений вместе с клиентами.",
      likes: 43,
      comments: 8,
      birthday: false,
      image: "/bio-event-irina-1.webp",
    },
    {
      id: "jun-2",
      month: "Июнь 2026",
      dateLabel: "17 июня",
      category: "Логистика",
      tone: "blue",
      author: "Складской комплекс",
      initials: "СК",
      time: "17 июня",
      title: "Склад перешёл на новый порядок комплектации",
      text: "Маршруты сборки стали короче, а контроль комплектности теперь выполняется на каждом этапе заказа.",
      likes: 55,
      comments: 13,
      birthday: false,
      image: "/bio-logistics.png",
    },
    {
      id: "jun-3",
      month: "Июнь 2026",
      dateLabel: "3 июня",
      category: "Объявление",
      tone: "announcement",
      author: "Администрация BIO",
      initials: "BIO",
      time: "3 июня",
      title: "Летний график работы офисов",
      text: "Опубликован порядок работы офисов и складского комплекса в период государственных праздников.",
      likes: 18,
      comments: 2,
      birthday: false,
      image: "/bio-about.png",
    },
  ];
  const archiveItems: ArchivedNewsItem[] = [
    ...newsStream.map((item, index) => {
      const isAi = item.category === "Обзор рынка";
      const isEvent = item.category === "Общее событие";
      return {
        ...item,
        month: "Август 2026",
        dateLabel: item.time.startsWith("Сегодня")
          ? "13 августа"
          : item.time.startsWith("Вчера")
            ? "12 августа"
            : item.time.split(" · ")[0],
        image: isAi
          ? "/bio-logistics.png"
          : isEvent
            ? item.title.includes("Carboma")
              ? "/bio-event-irina-2.webp"
              : "/bio-event-irina-3.webp"
            : item.id === 2
              ? "/bio-logistics.png"
              : item.id === 3
                ? "/gallery/bio-pirate-night-team.jpg"
                : item.id === 4
                  ? "/bio-about.png"
                  : index % 2
                    ? "/bio-event-irina-2.webp"
                    : "/bio-event-irina-1.webp",
      };
    }),
    ...historicalNews,
  ];
  const normalizedQuery = query.trim().toLowerCase();
  const newsTopics = [
    "Все",
    "Опрос",
    "Адаптация",
    "Команда",
    "Проекты",
    "Полезное",
    "Важно",
  ];
  const topicKeywords: Record<string, string[]> = {
    Опрос: ["опрос", "голосован"],
    Адаптация: ["адаптац", "новых коллег", "добро пожаловать", "персонал"],
    Команда: ["команда", "компания", "сотрудник"],
    Проекты: ["проект", "поставщик", "поставка", "carboma"],
    Полезное: ["обучен", "курс", "сервис", "практик"],
    Важно: ["объявление", "общая встреча", "обновление", "важно"],
  };
  
  
  const topicResults =
    activeTopic === "Все"
      ? []
      : newsStream.filter((item) => {
          const searchable =
            `${item.title} ${item.text} ${item.author} ${item.category}`.toLowerCase();
          return (topicKeywords[activeTopic] ?? []).some((keyword) =>
            searchable.includes(keyword),
          );
        });
  const searchResults = normalizedQuery
    ? newsStream.filter((item) =>
        `${item.title} ${item.text} ${item.author} ${item.category}`
          .toLowerCase()
          .includes(normalizedQuery),
      )
    : topicResults;
  const quickLinks: {
    id: string;
    label: string;
    description: string;
    icon: IconName;
    count?: string;
  }[] = [
    { id: "home", label: "Мой кабинет", description: "", icon: "home" },
    {
      id: "tasks",
      label: "Задачи",
      description: "",
      icon: "tasks",
      count: "7",
    },
    {
      id: "learning",
      label: "Курсы",
      description: "",
      icon: "learning",
      count: "2",
    },
    { id: "people", label: "Сотрудники", description: "", icon: "people" },
  ];
  const submitSearch = () => {
    setSearchFocused(false);
    onToast(
      normalizedQuery
        ? searchResults.length
          ? `Найдено: ${searchResults.length}`
          : `По слову «${query.trim()}» ничего не найдено`
        : "Введите одно ключевое слово",
    );
  };
  if (archiveOpen)
    return (
      <>
        <NewsArchivePage
          items={archiveItems}
          onBack={() => setArchiveOpen(false)}
          onOpen={(item) => setSelectedNews(item)}
        />
        {selectedNews && (
          <NewsDetailModal
            item={selectedNews}
            onClose={() => setSelectedNews(null)}
            onToast={onToast}
          />
        )}
      </>
    );
  return (
    <section className="reference-news-page" aria-label="Новости компании BIO">
      <header className="reference-news-title news-start-header">
        <div>
          <span className="date-label">Понедельник, 10 августа</span>
          <h1>Доброе утро, Ирина!</h1>
          <p
            className="daily-motivation"
            aria-live="polite"
            aria-label={`Цитата дня. ${dailyMotivation.quote.replace(/[.!?]+$/, "")}. Автор: ${dailyMotivation.author}`}
          >
            <span>
              <Icon name="sparkles" size={16} />
            </span>
            <em>«{dailyMotivation.quote.replace(/[.!?]+$/, "")}».</em>
            <b>{dailyMotivation.author}</b>
          </p>
        </div>
      </header>
      <nav className="news-start-shortcuts card" aria-label="Быстрые переходы">
        {quickLinks.map((item) => (
          <button key={item.id} onClick={() => onNavigate(item.id)}>
            <span>
              <Icon name={item.icon} size={19} />
            </span>
            <p>
              <strong>{item.label}</strong>
              {item.description && <small>{item.description}</small>}
            </p>
            {item.count ? <b>{item.count}</b> : <i>→</i>}
          </button>
        ))}
      </nav>
      <div className="news-board-v2">
        <section className="news-board-main card" aria-label="Лента новостей">
          <header className="news-board-toolbar news-board-toolbar-refined">
            <div className="news-board-title">
              <SectionIcon name="news" />
              <div>
                <h3 className="cabinet-block-heading">Новости BIO</h3>
                <a className="news-editor-entry" href="/news/manage">Вход в редакцию</a>
              </div>
            </div>
            <form
              role="search"
              aria-label="Поиск по новостям"
              onSubmit={(event) => {
                event.preventDefault();
                submitSearch();
              }}
            >
              <Icon name="search" size={17} />
              <input
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setActiveTopic("Все");
                }}
                placeholder="Найти новость"
                aria-label="Поиск новостей"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  aria-label="Очистить поиск"
                >
                  <Icon name="x" size={14} />
                </button>
              )}
            </form>
            <nav className="news-topic-filter" aria-label="Темы новостей">
              {newsTopics.map((label) => (
                <button
                  key={label}
                  type="button"
                  aria-pressed={activeTopic === label}
                  className={activeTopic === label ? "active" : ""}
                  onClick={() => {
                    setActiveTopic(label);
                    setSearchFocused(false);
                  }}
                >
                  {label}
                </button>
              ))}
            </nav>
          </header>
          {(normalizedQuery || activeTopic !== "Все" && activeTopic !== "Опрос") && (
            <div className="news-board-search-results" aria-live="polite">
              <span>
                {searchResults.length
                  ? `${normalizedQuery ? "Найдено" : activeTopic}: ${searchResults.length}`
                  : "Ничего не найдено"}
              </span>
              {searchResults.slice(0, 4).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedNews(item as NewsDetailItem)}
                >
                  {item.title}
                </button>
              ))}
              {activeTopic !== "Все" && (
                <button
                  className="news-results-reset"
                  onClick={() => setActiveTopic("Все")}
                >
                  Сбросить
                </button>
              )}
            </div>
          )}
          <PublishedNews query={query} topic={activeTopic} />
          <div className={`news-board-stories${activeTopic === "Опрос" ? " is-poll-only" : ""}`}>
            <div className="news-poll-featured-example"><NewsWeeklyPoll /></div>
            {activeTopic !== "Опрос" && <button
              className="news-story-small"
              onClick={() => setSelectedNews(regularNews[1] as NewsDetailItem)}
            >
              <span
                className="news-story-image"
                style={{ backgroundImage: "url(/bio-event-irina-2.webp)" }}
              />
              <span className="news-pills">
                <i>Проекты</i>
                <i>Полезное</i>
              </span>
              <h3>{regularNews[1].title}</h3>
              <time>{regularNews[1].time}</time>
              <footer>
                <span>♡ {regularNews[1].likes}</span>
                <span>▢ {regularNews[1].comments}</span>
                <NewsViews count={86} />
              </footer>
            </button>}
            {activeTopic !== "Опрос" && <button className="news-story-small" onClick={() => setSelectedNews(regularNews[0] as NewsDetailItem)}>
              <span className="news-story-image news-access-illustration" aria-hidden="true"><Icon name="door" size={44} /><span>Доступ в офис</span></span>
              <span className="news-pills"><i>Важно</i><i>Команда</i></span>
              <h3>{regularNews[0].title}</h3><time>{regularNews[0].time}</time>
              <footer><span>♡ {regularNews[0].likes}</span><span>▢ {regularNews[0].comments}</span><NewsViews count={127} /></footer>
            </button>}
          </div>
          <footer className="news-board-pagination">
            <span>Пример корпоративной ленты</span>
            <button onClick={() => setArchiveOpen(true)}>
              Все новости <b>→</b>
            </button>
          </footer>
        </section>
        <div className="news-second-row">
          <NewsBirthdays cityFor={person => directoryEmployeeProfiles.find(profile => profile.name === person.name)?.location || "Город не указан"} onOpen={person => {
            const known = directoryEmployeeProfiles.find(profile => profile.name === person.name);
            setSelectedBirthdayProfile({ ...(known ?? { initials: person.initials, name: person.name, role: "Сотрудник", department: person.meta.split(" · ")[1], phone: "", email: "", location: "", online: false, status: "", statusTone: "offline" as const, skills: [], manager: "" }), photo: person.photo, position: person.position });
          }} />
          <article className="card news-calendar-v2 personal-calendar-card profile-calendar-card">
            <WorkspaceEventsCalendar onToast={onToast} corporateEvents={corporateCalendarEvents} />
          </article>
        </div>
        <div className="news-third-row">
          <article className="card news-newcomers-v2">
            <header>
              <div className="news-section-title"><SectionIcon name="person" /><h3 className="cabinet-block-heading">Успешного старта</h3></div>
              <span>Август</span>
            </header>
            <div className="newcomer-photo-grid-v2">
              {newcomers.map((person, index) => (
                <button
                  className={index === 0 ? "featured" : ""}
                  key={person.name}
                  onClick={() => setSelectedNewcomer(person)}
                  style={{
                    backgroundImage: `linear-gradient(180deg,rgba(18,20,18,.02) 28%,rgba(18,20,18,.9)),url(${person.photo})`,
                    backgroundPosition: person.position,
                  }}
                >
                  <strong>{person.name}</strong>
                  <small>{person.role}</small>
                  <em>{person.meta}</em>
                </button>
              ))}
            </div>
          </article>
          <article className="card news-vacancies-v2">
            <header>
              <div className="news-section-title"><SectionIcon name="list" /><h3 className="cabinet-block-heading">Вакансии</h3></div>
              <button onClick={() => onNavigate("jobs")}>Все →</button>
            </header>
            {vacancies.map((item) => (
              <button key={item.title} onClick={() => setSelectedVacancy(item)}>
                <span>
                  <strong>{item.title}</strong>
                  <small>{item.department}</small>
                  <em>{item.meta}</em>
                </span>
                <b>→</b>
              </button>
            ))}
          </article>
        </div>
        <CorporateGallery />
      </div>
      
      {newsModalOpen && (
        <SuggestNewsModal
          onClose={() => setNewsModalOpen(false)}
          onSubmit={(topic) => {
            setNewsModalOpen(false);
            onToast(
              `Новость «${topic}» отправлена на согласование в отдел персонала`,
            );
          }}
        />
      )}
      {selectedNews && (
        <NewsDetailModal
          item={selectedNews}
          onClose={() => setSelectedNews(null)}
          onToast={onToast}
        />
      )}
      {selectedVacancy && (
        <VacancyDetailModal
          vacancy={selectedVacancy}
          onClose={() => setSelectedVacancy(null)}
        />
      )}
      {selectedBirthdayProfile && <EmployeeProfilePanel person={selectedBirthdayProfile} onClose={() => setSelectedBirthdayProfile(null)} onToast={onToast} onStartChat={onStartChat} onStartMail={email => { window.location.href = `mailto:${email}`; }} />}
      {selectedNewcomer && (
        <NewcomerProfileModal
          person={selectedNewcomer}
          onClose={() => setSelectedNewcomer(null)}
          onMessage={() => {
            const name = selectedNewcomer.name;
            setSelectedNewcomer(null);
            onStartChat(name);
          }}
        />
      )}
    </section>
  );
}
export { CorporateNewsDashboard };
