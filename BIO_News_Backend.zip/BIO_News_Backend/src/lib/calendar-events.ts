export function employeeCalendarEvents<T extends { participants: readonly string[] }>(
  events: Record<string, T>,
  employee: string,
): Record<string, T> {
  return Object.fromEntries(Object.entries(events).filter(([, event]) => event.participants.includes(employee)));
}

export const corporateCalendarEvents = {
  "2026-08-03": { title: "День арбуза", meta: "3 августа · 15:00 · офис и онлайн", organizer: "Отдел персонала", description: "Летняя встреча команды: арбузная дегустация и короткая викторина для коллег в офисе и онлайн.", participants: [], tone: "celebration" },
  "2026-08-10": { title: "Общая встреча BIO", meta: "10 августа · 15:00 · Teams", organizer: "Команда BIO", description: "Новости подразделений, итоги месяца и ответы на вопросы сотрудников.", participants: [], tone: "meeting" },
  "2026-08-21": { title: "Командный день BIO", meta: "21 августа · 16:00 · офис и онлайн", organizer: "Отдел персонала", description: "Командная игра и общение с коллегами с подключением обеих площадок.", participants: [], tone: "team" },
  "2026-09-10": { title: "Бутерброд-конструктор", meta: "10 сентября · 15:00 · офис и онлайн", organizer: "Команда BIO", description: "Короткий тематический день: собираем необычные сочетания и выбираем командный рецепт.", participants: [], tone: "celebration" },
};
