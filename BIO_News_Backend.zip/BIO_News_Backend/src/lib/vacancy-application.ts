/** Open a reviewable email draft; the employee attaches and sends the CV. */
export function vacancyResumeMailto(title: string, recipient: string) {
  if (!/^[^\s?&%<>]+@[^\s?&%<>]+\.[^\s?&%<>]+$/.test(recipient)) throw new Error("Некорректный адрес отдела персонала");
  const vacancy = title.replace(/[\r\n]+/g, " ").trim();
  const subject = `Резюме на вакансию «${vacancy}»`;
  const body = `Здравствуйте!\n\nПрошу рассмотреть резюме на вакансию «${vacancy}».\n\nРезюме прикреплю к этому письму.`;
  return `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
