// Local Vite development preview only. Never shipped in dist; not a production backend.
export function newsMock(){
 const favorites=new Set(),likes=new Set();let selected=null;
 const options=[['countryside','Турбаза'],['restaurant','Ресторан'],['either','Подходит и ресторан, и турбаза'],['office','Встреча в офисе'],['not-attending','Не планирую участвовать']];
 const poll=()=>({id:'bio-corporate-events-v1',question:'Надо ли что-то менять в организации корпоративов?',selected,total:selected?1:0,options:options.map(([id,label])=>({id,label,count:selected===id?1:0,percentage:selected===id?100:0}))});
 const reactions=()=>({year:new Date().getFullYear().toString(),items:['u-petrova','u-manager','u-elena','u-dealer'].map(recipientId=>({recipientId,count:likes.has(recipientId)?1:0,liked:likes.has(recipientId),canLike:true}))});
 return {name:'bio-news-local-preview',apply:'serve',configureServer(server){server.middlewares.use(async(req,res,next)=>{
  const url=new URL(req.url,'http://localhost');if(!url.pathname.startsWith('/api/'))return next();
  const send=(data,status=200)=>{res.statusCode=status;res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(data));};
  try{let body={};if(!['GET','HEAD'].includes(req.method)){let bytes=0,raw='';for await(const chunk of req){bytes+=chunk.length;if(bytes>128*1024)return send({error:{message:'Слишком большой запрос'}},413);raw+=chunk;}body=raw?JSON.parse(raw):{};}
   if(url.pathname==='/api/news/weekly-poll'){if(req.method==='PUT'){if(!options.some(([id])=>id===body.optionId))return send({error:{message:'Выберите вариант ответа'}},400);selected=body.optionId;}return send(poll());}
   if(url.pathname==='/api/birthdays/likes'){if(req.method==='PUT'){if(!reactions().items.some(x=>x.recipientId===body.recipientId)||typeof body.liked!=='boolean')return send({error:{message:'Выберите коллегу'}},400);body.liked?likes.add(body.recipientId):likes.delete(body.recipientId);}return send(reactions());}
   if(url.pathname==='/api/gallery/favorites'){if(req.method==='PUT'){body.favorite?favorites.add(body.photoId):favorites.delete(body.photoId);return send({photoId:body.photoId,favorite:body.favorite});}return send({photoIds:[...favorites]});}
   if(url.pathname==='/api/news-cms/feed')return send({posts:[]});
   if(url.pathname==='/api/news-cms/session')return send({user:null});
   return send({error:{message:'Для работы редакции подключите backend: см. README.md и docs/API.md.'}},503);
  }catch{return send({error:{message:'Некорректный запрос'}},400);}
 });}};
}
