-- SQLite / D1. Только таблицы, нужные модулю Новости. Без пользовательских данных.

CREATE TABLE IF NOT EXISTS news_accounts (username TEXT PRIMARY KEY, role TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 1, enabled INTEGER NOT NULL DEFAULT 1);

CREATE TABLE IF NOT EXISTS news_sessions (token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, expires_at INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS news_login_limits (key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, expires_at INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS news_posts (id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL, event_date TEXT NOT NULL, status TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS news_assets (id TEXT PRIMARY KEY, post_id TEXT NOT NULL, storage_key TEXT NOT NULL, mime TEXT NOT NULL, name TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS birthday_likes (year TEXT NOT NULL, recipient_id TEXT NOT NULL, sender_id TEXT NOT NULL, PRIMARY KEY(year,recipient_id,sender_id));

CREATE TABLE IF NOT EXISTS news_poll_votes (poll_id TEXT NOT NULL,user_id TEXT NOT NULL,option_id TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(poll_id,user_id));

--> statement-breakpoint
CREATE TABLE `portal_notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`title` text NOT NULL,
	`detail` text NOT NULL,
	`section` text NOT NULL,
	`target_id` text NOT NULL,
	`read_at` text,
	`created_at` text NOT NULL
);

CREATE TABLE `gallery_favorites` (
	`user_id` text NOT NULL,
	`photo_id` text NOT NULL,
	`created_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `photo_id`)
);

--> statement-breakpoint
CREATE TABLE `user_role_overrides` (
	`user_id` text PRIMARY KEY NOT NULL,
	`role` text NOT NULL,
	`changed_by` text NOT NULL,
	`updated_at` text NOT NULL
);

--> statement-breakpoint
CREATE TABLE `user_employment_states` (
	`user_id` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`changed_by` text NOT NULL,
	`updated_at` text NOT NULL
);
