import { portalDb } from "../../../../lib/database";
import { newsBirthdays } from "../../../../lib/news-birthdays";
import { forbiddenResponse, hasPermission, resolveSessionForRequest } from "../../../../lib/rbac";

const year = () => new Intl.DateTimeFormat("en", { timeZone: "Europe/Moscow", year: "numeric" }).format(new Date());
const receiptTitle = "Шарик отправлен";

export async function GET(request: Request) {
  const session = await resolveSessionForRequest(request);
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "communications.self.read")) return forbiddenResponse();
  try {
    const db = await portalDb();
    const rows = await db.prepare("SELECT target_id FROM portal_notifications WHERE user_id = ? AND title = ? AND section = 'news'")
      .bind(session.userId, receiptTitle).all<{ target_id: string }>();
    const prefix = `birthday-balloon:${year()}:`;
    return Response.json({ sent: rows.results.filter(row => row.target_id.startsWith(prefix)).map(row => row.target_id.slice(prefix.length)) }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return Response.json({ error: { message: "Не удалось загрузить поздравления." } }, { status: 503 });
  }
}

export async function POST(request: Request) {
  const session = await resolveSessionForRequest(request);
  const origin = request.headers.get("origin");
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "communications.self.read") ||
      origin && origin !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site") return forbiddenResponse();
  const body = await request.json().catch(() => null) as { recipientId?: string; senderId?: string } | null;
  const person = newsBirthdays.find(person => person.id === body?.recipientId);
  if (!person || body?.senderId && body.senderId !== session.userId) return Response.json({ error: { message: "Выберите сотрудника из списка именинников." } }, { status: 400 });
  if (person.id === session.userId) return Response.json({ error: { message: "Отправьте шарик коллеге." } }, { status: 400 });
  try {
    const db = await portalDb();
    const target = `birthday-balloon:${year()}:${person.id}`;
    const id = `${target}:${encodeURIComponent(session.userId)}`;
    const now = new Date().toISOString();
    const notice = (noticeId: string, userId: string, title: string, detail: string) => db.prepare("INSERT OR IGNORE INTO portal_notifications (id, user_id, title, detail, section, target_id, created_at) VALUES (?, ?, ?, ?, 'news', ?, ?)")
      .bind(noticeId, userId, title, detail, target, now);
    await db.batch([
      notice(`${id}:received`, person.id, "Вам прислали шарик 🎈", `${session.name} поздравляет вас с днём рождения!`),
      notice(`${id}:sent`, session.userId, receiptTitle, `Вы отправили шарик: ${person.name} 🎈`),
    ]);
    return Response.json({ recipientId: person.id, sent: true });
  } catch {
    return Response.json({ error: { message: "Шарик не отправлен. Попробуйте ещё раз." } }, { status: 503 });
  }
}
