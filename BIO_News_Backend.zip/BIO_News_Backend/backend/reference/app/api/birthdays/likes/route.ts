import { portalDb } from "../../../../lib/database";
import { newsBirthdays } from "../../../../lib/news-birthdays";
import { forbiddenResponse, hasPermission, resolveSessionForRequest } from "../../../../lib/rbac";

const year = () => new Intl.DateTimeFormat("en", { timeZone: "Europe/Moscow", year: "numeric" }).format(new Date());
async function database() {
  const db = await portalDb();
  await db.prepare("CREATE TABLE IF NOT EXISTS birthday_likes (year TEXT NOT NULL, recipient_id TEXT NOT NULL, sender_id TEXT NOT NULL, PRIMARY KEY(year,recipient_id,sender_id))").run();
  return db;
}
async function summary(db: D1Database, userId: string) {
  const rows = await db.prepare("SELECT recipient_id,COUNT(*) AS total,MAX(CASE WHEN sender_id=? THEN 1 ELSE 0 END) AS liked FROM birthday_likes WHERE year=? GROUP BY recipient_id").bind(userId, year()).all<{ recipient_id: string; total: number; liked: number }>();
  return { year: year(), items: newsBirthdays.map(p => { const row = rows.results.find(r => r.recipient_id === p.id); return { recipientId: p.id, count: row?.total ?? 0, liked: !!row?.liked, canLike: p.id !== userId }; }) };
}
const response = (value: unknown) => Response.json(value, { headers: { "Cache-Control": "private, no-store" } });
export async function GET(request: Request) {
  const session = await resolveSessionForRequest(request);
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "communications.self.read")) return forbiddenResponse();
  try { return response(await summary(await database(), session.userId)); }
  catch { return Response.json({ error: { message: "Не удалось загрузить поздравления." } }, { status: 503 }); }
}
export async function PUT(request: Request) {
  const session = await resolveSessionForRequest(request), origin = request.headers.get("origin"), url = new URL(request.url);
  const local = ["localhost", "127.0.0.1", "terminal.local"].includes(url.hostname);
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "communications.self.read") || (!origin && !local) || origin && origin !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") return forbiddenResponse();
  const body = await request.json().catch(() => null);
  const person = newsBirthdays.find(p => p.id === body?.recipientId);
  if (!person || typeof body?.liked !== "boolean" || body.senderId && body.senderId !== session.userId || person.id === session.userId) return Response.json({ error: { message: "Выберите коллегу из списка именинников." } }, { status: 400 });
  try {
    const db = await database(), target = `birthday-like:${year()}:${person.id}`, id = `${target}:${encodeURIComponent(session.userId)}`;
    await db.batch(body.liked ? [
      db.prepare("INSERT OR IGNORE INTO birthday_likes (year,recipient_id,sender_id) VALUES (?,?,?)").bind(year(), person.id, session.userId),
      db.prepare("INSERT OR IGNORE INTO portal_notifications (id,user_id,title,detail,section,target_id,created_at) VALUES (?,?,?,?,'news',?,?)").bind(id, person.id, "Вас поздравили с днём рождения ♥", `${session.name} поставил(а) лайк-поздравление.`, target, new Date().toISOString()),
    ] : [
      db.prepare("DELETE FROM birthday_likes WHERE year=? AND recipient_id=? AND sender_id=?").bind(year(), person.id, session.userId),
      db.prepare("DELETE FROM portal_notifications WHERE id=? AND user_id=?").bind(id, person.id),
    ]);
    return response(await summary(db, session.userId));
  } catch { return Response.json({ error: { message: "Поздравление не сохранено. Попробуйте ещё раз." } }, { status: 503 }); }
}
