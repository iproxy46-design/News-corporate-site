import { newsRequest } from "../../../../lib/news-cms";
type Context = { params: Promise<{ path: string[] }> };
async function handle(request: Request, context: Context) { return newsRequest(request, (await context.params).path); }
export const GET = handle;
export const POST = handle;
export const PATCH = handle;
export const DELETE = handle;
