import { portalDb } from "../../../../lib/database";
import { galleryPhotos } from "../../../../lib/gallery";
import { forbiddenResponse, hasPermission, resolveSessionForRequest } from "../../../../lib/rbac";

export async function GET(request: Request) {
  const session = await resolveSessionForRequest(request);
  const target = new URL(request.url).searchParams.get("userId");
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "profile.self.read") || target && target !== session.userId) return forbiddenResponse();
  try {
    const rows = await (await portalDb()).prepare("SELECT photo_id FROM gallery_favorites WHERE user_id = ? ORDER BY created_at DESC, photo_id")
      .bind(session.userId).all<{ photo_id: string }>();
    const catalogIds = new Set(galleryPhotos.map(photo => photo.id));
    return Response.json({ photoIds: rows.results.map(row => row.photo_id).filter(id => catalogIds.has(id)) }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return Response.json({ error: { message: "Не удалось загрузить избранные фотографии." } }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  const session = await resolveSessionForRequest(request);
  const origin = request.headers.get("origin");
  const target = new URL(request.url).searchParams.get("userId");
  if (session.userId === "anonymous" || session.employmentState === "inactive" || !hasPermission(session, "profile.self.update") ||
      origin && origin !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site" || target && target !== session.userId) return forbiddenResponse();
  const body = await request.json().catch(() => null) as { photoId?: string; favorite?: boolean; userId?: string } | null;
  if (body?.userId && body.userId !== session.userId) return forbiddenResponse();
  if (!body || typeof body.favorite !== "boolean" || !galleryPhotos.some(photo => photo.id === body.photoId)) {
    return Response.json({ error: { message: "Выберите фотографию из галереи BIO." } }, { status: 400 });
  }
  try {
    const db = await portalDb();
    if (body.favorite) await db.prepare("INSERT INTO gallery_favorites (user_id, photo_id, created_at) VALUES (?, ?, ?) ON CONFLICT(user_id, photo_id) DO NOTHING")
      .bind(session.userId, body.photoId, new Date().toISOString()).run();
    else await db.prepare("DELETE FROM gallery_favorites WHERE user_id = ? AND photo_id = ?").bind(session.userId, body.photoId).run();
    return Response.json({ photoId: body.photoId, favorite: body.favorite });
  } catch {
    return Response.json({ error: { message: "Не удалось сохранить избранное. Попробуйте ещё раз." } }, { status: 503 });
  }
}
