import { portalDb } from "../../../../lib/database";
import { weeklyPoll } from "../../../../lib/news-weekly-poll";
import { forbiddenResponse, resolveSessionForRequest } from "../../../../lib/rbac";

async function database() {
  const db = await portalDb();
  await db.prepare("CREATE TABLE IF NOT EXISTS news_poll_votes (poll_id TEXT NOT NULL,user_id TEXT NOT NULL,option_id TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(poll_id,user_id))").run();
  return db;
}
async function result(db: D1Database, userId: string) {
  const rows = (await db.prepare("SELECT option_id,COUNT(*) AS count FROM news_poll_votes WHERE poll_id=? GROUP BY option_id").bind(weeklyPoll.id).all<{ option_id: string; count: number }>()).results;
  const selected = await db.prepare("SELECT option_id FROM news_poll_votes WHERE poll_id=? AND user_id=?").bind(weeklyPoll.id, userId).first<{ option_id: string }>();
  const total = rows.reduce((sum, row) => sum + row.count, 0);
  return { ...weeklyPoll, total, selected: selected?.option_id ?? null, options: weeklyPoll.options.map(option => {
    const count = rows.find(row => row.option_id === option.id)?.count ?? 0;
    return { ...option, count, percentage: total ? Math.round(count / total * 1000) / 10 : 0 };
  }) };
}
export async function GET(request: Request) {
  const session = await resolveSessionForRequest(request);
  if (session.userId === "anonymous" || session.employmentState === "inactive") return forbiddenResponse();
  try { return Response.json(await result(await database(), session.userId), { headers: { "Cache-Control": "private, no-store" } }); }
  catch { return Response.json({ error: { message: "Не удалось загрузить опрос. Повторите попытку." } }, { status: 503 }); }
}
export async function PUT(request: Request) {
  const session = await resolveSessionForRequest(request), origin = request.headers.get("origin"), url = new URL(request.url);
  const local = ["localhost", "127.0.0.1", "terminal.local"].includes(url.hostname);
  if (session.userId === "anonymous" || session.employmentState === "inactive" || (!origin && !local) || origin && origin !== url.origin || request.headers.get("sec-fetch-site") === "cross-site") return forbiddenResponse();
  const body = await request.json().catch(() => null);
  if (!body || !weeklyPoll.options.some(option => option.id === body.optionId) || body.userId !== undefined || body.pollId !== undefined) return Response.json({ error: { message: "Выберите один из вариантов ответа." } }, { status: 400 });
  try {
    const db = await database();
    await db.prepare("INSERT INTO news_poll_votes (poll_id,user_id,option_id,updated_at) VALUES (?,?,?,?) ON CONFLICT(poll_id,user_id) DO UPDATE SET option_id=excluded.option_id,updated_at=excluded.updated_at").bind(weeklyPoll.id, session.userId, body.optionId, new Date().toISOString()).run();
    return Response.json(await result(db, session.userId), { headers: { "Cache-Control": "private, no-store" } });
  } catch { return Response.json({ error: { message: "Ответ не сохранён. Попробуйте ещё раз." } }, { status: 503 }); }
}
