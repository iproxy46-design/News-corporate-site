export type GalleryPhoto = { id: string; src: string; title: string; date: string; meta: string; position?: string };

export const galleryPhotos: GalleryPhoto[] = [
  {
    id: "team-meeting-2026",
    src: "/bio-event-irina-1.webp",
    title: "Ежегодная встреча команды",
    date: "2026",
    meta: "Ирина на корпоративном town hall · Москва",
  },
  {
    id: "horeca-expo-2026",
    src: "/bio-event-irina-2.webp",
    title: "HoReCa Expo",
    date: "2026",
    meta: "Встреча с партнёрами и командами направлений",
  },
  {
    id: "team-day-2026",
    src: "/bio-event-irina-3.webp",
    title: "Командный день BIO",
    date: "Лето 2026",
    meta: "Корпоративное мероприятие · лето 2026",
  },
  {
    id: "sea-evening-details-2026",
    src: "/gallery/bio-pirate-night-details.jpg",
    title: "Атмосфера морского вечера",
    date: "2026",
    meta: "Декор и детали корпоративного мероприятия",
    position: "center 54%",
  },
  {
    id: "sea-evening-atmosphere-2026",
    src: "/gallery/bio-pirate-night-atmosphere.jpg",
    title: "В духе приключений",
    date: "2026",
    meta: "Тематические образы и настроение команды",
    position: "center 58%",
  },
];
