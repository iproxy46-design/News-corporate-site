import {MAX_PROFILE_PHOTO_BYTES} from "./profile-photo-limits";
export async function validateProfilePhoto(file: File) {
  if (!file.size || file.size > MAX_PROFILE_PHOTO_BYTES) throw new Error("Выберите фото размером до 5 МБ.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  let mime: string | null = null;
  if (bytes.length >= 45 && [137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => bytes[index] === value) &&
      new TextDecoder().decode(bytes.slice(12, 16)) === "IHDR" && new TextDecoder().decode(bytes.slice(-8, -4)) === "IEND") {
    const header = new DataView(bytes.buffer);
    if (header.getUint32(16) > 0 && header.getUint32(20) > 0 && header.getUint32(16) <= 8000 && header.getUint32(20) <= 8000) mime = "image/png";
  } else if (bytes.length >= 4 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 && bytes.at(-2) === 255 && bytes.at(-1) === 217) {
    mime = "image/jpeg";
  } else if (bytes.length >= 28 && new TextDecoder().decode(bytes.slice(0, 4)) === "RIFF" &&
      new TextDecoder().decode(bytes.slice(8, 12)) === "WEBP" && new DataView(bytes.buffer).getUint32(4, true) + 8 === bytes.length) {
    mime = "image/webp";
  }
  if (!mime || file.type && file.type !== mime) throw new Error("Загрузите корректное изображение JPG, PNG или WebP.");
  return { bytes, mime };
}
