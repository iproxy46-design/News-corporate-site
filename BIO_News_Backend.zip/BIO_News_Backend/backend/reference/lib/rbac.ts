import { people } from "./portal-directory";

export type PortalRole = "employee" | "manager" | "admin";

export type EmploymentState = "onboarding" | "active" | "inactive";

export type PortalProfile =
  | "employee"
  | "onboardingEmployee"
  | "manager"
  | "executive"
  | "admin"
  | "technicalAdmin";

export type Scope = "self" | "team" | "orgBranch" | "all";

export type Permission =
  | "profile.self.read"
  | "profile.self.update"
  | "tasks.self.read"
  | "tasks.self.create"
  | "tasks.team.read"
  | "tasks.team.create"
  | "tasks.crossDepartment.create"
  | "kpi.self.read"
  | "kpi.team.read"
  | "competencies.self.read"
  | "competencies.team.read"
  | "learning.self.read"
  | "learning.team.assign"
  | "learning.content.publish"
  | "adaptation.self.read"
  | "adaptation.self.update"
  | "adaptation.mentor.assign"
  | "adaptation.complete"
  | "recruitment.create"
  | "recruitment.approve"
  | "knowledge.read"
  | "knowledge.publish"
  | "communications.self.read"
  | "reports.team.export"
  | "admin.users.manage"
  | "integrations.retry";

export type PortalSession = {
  userId: string;
  name: string;
  email: string;
  role: PortalRole;
  profile: PortalProfile;
  departmentId: string;
  managerId: string | null;
  employmentState: EmploymentState;
  permissions: Permission[];
  scopes: Partial<Record<Permission, Scope>>;
  extras: Permission[];
  scopeOverrides: Partial<Record<Permission, Scope>>;
};

type SessionTemplate = Omit<
  PortalSession,
  "permissions" | "scopes" | "extras" | "scopeOverrides"
> & {
  extras?: Permission[];
  scopeOverrides?: Partial<Record<Permission, Scope>>;
};

const employeePermissions: Permission[] = [
  "profile.self.read",
  "profile.self.update",
  "tasks.self.read",
  "tasks.self.create",
  "kpi.self.read",
  "competencies.self.read",
  "learning.self.read",
  "adaptation.self.read",
  "adaptation.self.update",
  "knowledge.read",
  "communications.self.read",
];

const managerPermissions: Permission[] = [
  ...employeePermissions,
  "tasks.team.read",
  "tasks.team.create",
  "kpi.team.read",
  "competencies.team.read",
  "learning.team.assign",
  "adaptation.mentor.assign",
  "adaptation.complete",
  "recruitment.create",
  "reports.team.export",
];

// The hierarchy is cumulative. Technical operations are never inherited and
// stay explicit even for a business administrator.
const adminPermissions: Permission[] = [
  ...managerPermissions,
  "learning.content.publish",
  "knowledge.publish",
  "admin.users.manage",
];

const profileTemplates: Record<PortalProfile, SessionTemplate> = {
  employee: {
    userId: "u-irina",
    name: "Ирина Марухленко",
    email: "i.marukhlenko@holdingbio.ru",
    role: "employee",
    profile: "employee",
    departmentId: "import-procurement",
    managerId: "u-manager",
    employmentState: "active",
  },
  onboardingEmployee: {
    userId: "u-anastasia",
    name: "Анастасия Воронцова",
    email: "a.vorontsova@holdingbio.ru",
    role: "employee",
    profile: "onboardingEmployee",
    departmentId: "import-procurement",
    managerId: "u-manager",
    employmentState: "onboarding",
  },
  manager: {
    userId: "u-manager",
    name: "Алексей Соколов",
    email: "a.sokolov@holdingbio.ru",
    role: "manager",
    profile: "manager",
    departmentId: "import-procurement",
    managerId: "u-executive",
    employmentState: "active",
  },
  executive: {
    userId: "u-executive",
    name: "Анна Смирнова",
    email: "a.smirnova@holdingbio.ru",
    role: "manager",
    profile: "executive",
    departmentId: "procurement-branch",
    managerId: "u-ceo",
    employmentState: "active",
    extras: ["recruitment.approve", "tasks.crossDepartment.create"],
    scopeOverrides: {
      "tasks.team.read": "orgBranch",
      "tasks.team.create": "orgBranch",
      "kpi.team.read": "orgBranch",
      "competencies.team.read": "orgBranch",
      "learning.team.assign": "orgBranch",
      "adaptation.mentor.assign": "orgBranch",
      "adaptation.complete": "orgBranch",
      "reports.team.export": "orgBranch",
      "tasks.crossDepartment.create": "orgBranch",
      "recruitment.approve": "orgBranch",
    },
  },
  admin: {
    userId: "u-admin",
    name: "Ирина Марухленко",
    email: "learning.admin@holdingbio.ru",
    role: "admin",
    profile: "admin",
    departmentId: "learning",
    managerId: "u-hr-director",
    employmentState: "active",
  },
  technicalAdmin: {
    userId: "u-tech",
    name: "Технический администратор",
    email: "portal.admin@holdingbio.ru",
    role: "admin",
    profile: "technicalAdmin",
    departmentId: "it",
    managerId: "u-it-director",
    employmentState: "active",
    extras: ["integrations.retry"],
  },
};

const identityProfileMap: Record<string, PortalProfile> = Object.fromEntries(
  Object.values(profileTemplates).map((template) => [template.email, template.profile]),
);

const qaOperatorEmails = new Set(["iproxy46@gmail.com"]);

export function canUseQaRoleSwitch(request: Request): boolean {
  const authenticatedEmail = request.headers
    .get("oai-authenticated-user-email")
    ?.trim()
    .toLowerCase();
  if (authenticatedEmail) return qaOperatorEmails.has(authenticatedEmail);
  const hostname = new URL(request.url).hostname;
  return ["terminal.local", "localhost", "127.0.0.1"].includes(hostname);
}

function rolePermissions(role: PortalRole): Permission[] {
  if (role === "admin") return adminPermissions;
  if (role === "manager") return managerPermissions;
  return employeePermissions;
}

function defaultScope(permission: Permission): Scope {
  if (permission.includes(".team.")) return "team";
  if (permission.includes(".self.")) return "self";
  if (permission === "reports.team.export") return "team";
  if (permission === "adaptation.mentor.assign" || permission === "adaptation.complete") return "team";
  if (permission === "recruitment.approve") return "team";
  return "self";
}

function authorizeSession(
  identity: Omit<PortalSession, "permissions" | "scopes">,
): PortalSession {
  const permissions = Array.from(
    new Set([...rolePermissions(identity.role), ...identity.extras]),
  );
  const scopes = Object.fromEntries(
    permissions.map((permission) => [
      permission,
      identity.scopeOverrides[permission] ?? defaultScope(permission),
    ]),
  ) as PortalSession["scopes"];
  return { ...identity, permissions, scopes };
}

export function createSession(profile: PortalProfile): PortalSession {
  const template = profileTemplates[profile] ?? profileTemplates.employee;
  return authorizeSession({
    ...template,
    extras: [...(template.extras ?? [])],
    scopeOverrides: { ...(template.scopeOverrides ?? {}) },
  });
}

function withRole(session: PortalSession, role: PortalRole): PortalSession {
  return authorizeSession({
    userId: session.userId,
    name: session.name,
    email: session.email,
    role,
    profile: role,
    departmentId: session.departmentId,
    managerId: session.managerId,
    employmentState: session.employmentState,
    extras: [],
    scopeOverrides: {},
  });
}

function qaProfileFromCookie(request: Request): PortalProfile {
  const cookie = request.headers.get("cookie") ?? "";
  const parts = cookie.split(";").map((part) => part.trim());
  const value =
    parts.find((part) => part.startsWith("bio_qa_profile="))?.split("=")[1] ??
    parts.find((part) => part.startsWith("bio_qa_role="))?.split("=")[1];
  const legacyMap: Record<string, PortalProfile> = {
    newEmployee: "onboardingEmployee",
  };
  const candidate = decodeURIComponent(value ?? "employee");
  const profile = legacyMap[candidate] ?? candidate;
  return profile in profileTemplates ? (profile as PortalProfile) : "employee";
}

export function sessionForRequest(request: Request): PortalSession {
  const authenticatedEmail = request.headers
    .get("oai-authenticated-user-email")
    ?.trim()
    .toLowerCase();
  if (authenticatedEmail && identityProfileMap[authenticatedEmail]) {
    return createSession(identityProfileMap[authenticatedEmail]);
  }
  if (canUseQaRoleSwitch(request)) return createSession(qaProfileFromCookie(request));

  const directoryPerson = authenticatedEmail ? people.find((person) => person.email.toLowerCase() === authenticatedEmail) : undefined;
  if (directoryPerson) {
    const employee = createSession(directoryPerson.isNewEmployee ? "onboardingEmployee" : "employee");
    return { ...employee, userId: directoryPerson.userId, name: directoryPerson.name, email: directoryPerson.email, departmentId: directoryPerson.departmentId, managerId: directoryPerson.managerId };
  }

  // An authenticated but unmapped viewer receives an isolated employee
  // identity, never the demo employee's records.
  const isolated = createSession("employee");
  return {
    ...isolated,
    userId: authenticatedEmail ? `unmapped:${authenticatedEmail}` : "anonymous",
    name: authenticatedEmail ?? "Неавторизованный пользователь",
    email: authenticatedEmail ?? "",
    departmentId: "unassigned",
    managerId: null,
  };
}

export async function resolveSessionForRequest(
  request: Request,
): Promise<PortalSession> {
  let session = sessionForRequest(request);
  const authenticatedEmail = request.headers
    .get("oai-authenticated-user-email")
    ?.trim()
    .toLowerCase();
  if (!authenticatedEmail || canUseQaRoleSwitch(request)) return session;

  try {
    const { portalDb } = await import("./database");
    const db = await portalDb();
    const [roleOverride, employmentOverride] = await Promise.all([
      db.prepare("SELECT role FROM user_role_overrides WHERE user_id = ?")
        .bind(session.userId)
        .first<{ role: PortalRole }>(),
      db.prepare("SELECT state FROM user_employment_states WHERE user_id = ?")
        .bind(session.userId)
        .first<{ state: EmploymentState }>(),
    ]);
    if (roleOverride?.role && ["employee", "manager", "admin"].includes(roleOverride.role)) {
      session = withRole(session, roleOverride.role);
    }
    if (employmentOverride?.state && ["onboarding", "active", "inactive"].includes(employmentOverride.state)) {
      session = { ...session, employmentState: employmentOverride.state };
    }
    return session;
  } catch {
    // Fail closed to the fixed directory role. A broken integration never
    // grants additional permissions or expands a data scope.
    return session;
  }
}

export function hasPermission(
  session: PortalSession,
  permission: Permission,
): boolean {
  return session.permissions.includes(permission);
}

export function forbiddenResponse(): Response {
  return Response.json(
    {
      error: {
        code: "FORBIDDEN",
        message: "Объект недоступен или доступ к нему был отозван.",
      },
    },
    { status: 403 },
  );
}

export function isInScope(
  session: PortalSession,
  target: { userId: string; departmentId: string; managerId?: string | null },
  permission: Permission,
): boolean {
  const scope = session.scopes[permission] ?? "self";
  if (scope === "all") return true;
  if (scope === "self") return target.userId === session.userId;
  if (scope === "team") return target.managerId === session.userId;
  if (scope === "orgBranch") {
    return (
      target.managerId === session.userId ||
      target.departmentId === session.departmentId ||
      (session.departmentId === "procurement-branch" &&
        ["import-procurement", "ru-procurement"].includes(target.departmentId))
    );
  }
  return false;
}

export const portalProfileOptions: Array<{ id: PortalProfile; label: string }> = [
  { id: "employee", label: "Сотрудник" },
  { id: "onboardingEmployee", label: "Сотрудник · адаптация" },
  { id: "manager", label: "Руководитель отдела" },
  { id: "executive", label: "Вышестоящий руководитель" },
  { id: "admin", label: "Администратор" },
  { id: "technicalAdmin", label: "Администратор + технический retry" },
];
