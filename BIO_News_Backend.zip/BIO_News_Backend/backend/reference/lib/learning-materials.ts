export async function courseBucket(): Promise<R2Bucket> {
  const injected = (globalThis as typeof globalThis & { __BIO_PORTAL_TEST_BUCKET__?: R2Bucket }).__BIO_PORTAL_TEST_BUCKET__;
  if (injected) return injected;
  const { env } = await import("cloudflare:workers");
  const bucket = (env as unknown as { BUCKET?: R2Bucket }).BUCKET;
  if (!bucket) throw new Error("Хранилище курсов временно недоступно.");
  return bucket;
}