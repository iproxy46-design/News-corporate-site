import { portalDb } from "./database";
import { courseBucket } from "./learning-materials";
import { validateProfilePhoto } from "./profile-photo";

export type NewsAccount = { username: "admin" | "editor"; role: "admin" | "editor"; salt: string; password_hash: string; must_change: number; enabled: number };
export type NewsPost = { id: string; kind: "news" | "album"; title: string; body: string; category: string; event_date: string; status: "draft" | "published"; version: number; updated_at: string };
type Asset = { id: string; post_id: string; storage_key: string; mime: string; name: string };
const cookieName = "__Host-bio_news";
const encoder = new TextEncoder();
const hex = (bytes: ArrayBuffer) => Array.from(new Uint8Array(bytes), n => n.toString(16).padStart(2, "0")).join("");
const random = () => hex(crypto.getRandomValues(new Uint8Array(32)).buffer);
export async function passwordHash(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: encoder.encode(salt), iterations: 100000, hash: "SHA-256" }, key, 256));
}
async function digest(value: string) { return hex(await crypto.subtle.digest("SHA-256", encoder.encode(value))); }
function equal(a: string, b: string) { let diff = a.length ^ b.length; for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0); return diff === 0; }
function fail(message: string, status = 400): never { throw Object.assign(new Error(message), { status }); }
function publicAccount(a: NewsAccount) { return { username: a.username, role: a.role, mustChangePassword: !!a.must_change, enabled: !!a.enabled }; }
function passwordValid(p: unknown): p is string { return typeof p === "string" && p.length >= 12 && p.length <= 128 && /[a-zа-я]/i.test(p) && /\d/.test(p); }
function mutation(request: Request) {
  if (request.headers.get("origin") !== new URL(request.url).origin || request.headers.get("sec-fetch-site") === "cross-site") fail("Запрос с другого сайта запрещён.", 403);
}
async function payload(request: Request): Promise<Record<string, unknown>> {
  if (Number(request.headers.get("content-length")) > 128 * 1024) fail("Слишком большой запрос.", 413);
  const value = await request.json();
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("Некорректный запрос.");
  return value;
}
export async function newsDb() {
  const db = await portalDb();
  await db.batch([
    db.prepare("CREATE TABLE IF NOT EXISTS news_accounts (username TEXT PRIMARY KEY, role TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, must_change INTEGER NOT NULL DEFAULT 1, enabled INTEGER NOT NULL DEFAULT 1)"),
    db.prepare("CREATE TABLE IF NOT EXISTS news_sessions (token_hash TEXT PRIMARY KEY, username TEXT NOT NULL, expires_at INTEGER NOT NULL)"),
    db.prepare("CREATE TABLE IF NOT EXISTS news_login_limits (key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, expires_at INTEGER NOT NULL)"),
    db.prepare("CREATE TABLE IF NOT EXISTS news_posts (id TEXT PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL, event_date TEXT NOT NULL, status TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL)"),
    db.prepare("CREATE TABLE IF NOT EXISTS news_assets (id TEXT PRIMARY KEY, post_id TEXT NOT NULL, storage_key TEXT NOT NULL, mime TEXT NOT NULL, name TEXT NOT NULL)"),
  ]);
  const injected = (globalThis as typeof globalThis & { __BIO_NEWS_TEST_ACCOUNTS__?: string }).__BIO_NEWS_TEST_ACCOUNTS__;
  const initial = injected ?? (await import("cloudflare:workers")).env.NEWS_INITIAL_ACCOUNTS;
  if (initial) {
    const accounts = JSON.parse(initial) as NewsAccount[];
    for (const a of accounts) if (["admin", "editor"].includes(a.username) && a.role === a.username && /^[a-f0-9]{64}$/.test(a.password_hash) && a.salt.length >= 32)
      await db.prepare("INSERT OR IGNORE INTO news_accounts (username,role,salt,password_hash) VALUES (?,?,?,?)").bind(a.username, a.role, a.salt, a.password_hash).run();
  }
  return db;
}
async function actor(db: D1Database, request: Request) {
  const token = request.headers.get("cookie")?.split(";").map(s => s.trim()).find(s => s.startsWith(cookieName + "="))?.slice(cookieName.length + 1);
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  return db.prepare("SELECT a.* FROM news_accounts a JOIN news_sessions s ON a.username=s.username WHERE s.token_hash=? AND s.expires_at>? AND a.enabled=1").bind(await digest(token), Date.now()).first<NewsAccount>();
}
async function required(db: D1Database, request: Request, passwordChange = false) {
  const a = await actor(db, request); if (!a) fail("Войдите как редактор или администратор.", 401);
  if (a.must_change && !passwordChange) fail("Сначала замените временный пароль.", 403);
  return a;
}
async function post(db: D1Database, id: string) { const row = await db.prepare("SELECT * FROM news_posts WHERE id=?").bind(id).first<NewsPost>(); if (!row) fail("Публикация не найдена.", 404); return row; }
async function assets(db: D1Database, id: string) { return (await db.prepare("SELECT * FROM news_assets WHERE post_id=? ORDER BY id").bind(id).all<Asset>()).results; }
async function withAssets(db: D1Database, row: NewsPost) { return { ...row, assets: (await assets(db, row.id)).map(a => ({ id: a.id, name: a.name, url: `/api/news-cms/assets/${a.id}` })) }; }
const sessionCookie = (value: string, age: number) => `${cookieName}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;

export async function newsRequest(request: Request, parts: string[]) {
  const headers = { "Cache-Control": "private, no-store" };
  const json = (data: unknown, extra: Record<string, string> = {}) => Response.json(data, { headers: { ...headers, ...extra } });
  try {
    const db = await newsDb(), [resource = "feed", id] = parts, method = request.method;
    if (!["GET", "HEAD"].includes(method)) mutation(request);
    if (resource === "session" && method === "GET") { const a = await actor(db, request); return json({ user: a ? publicAccount(a) : null }); }
    if (resource === "login" && method === "POST") {
      const { username: input, password } = await payload(request);
      const username = typeof input === "string" ? input.trim().toLowerCase().slice(0, 100) : "";
      const now = Date.now(), slot = Math.floor(now / 900000);
      const keys = [`account:${username}:${slot}`, `ip:${request.headers.get("cf-connecting-ip") || "unknown"}:${slot}`];
      await db.batch(keys.map(key => db.prepare("INSERT INTO news_login_limits (key,attempts,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=attempts+1").bind(key, now + 1800000)));
      for (const [i, key] of keys.entries()) { const limit = await db.prepare("SELECT attempts FROM news_login_limits WHERE key=?").bind(key).first<{ attempts: number }>(); if ((limit?.attempts ?? 0) > (i ? 30 : 10)) fail("Слишком много попыток. Повторите через 15 минут.", 429); }
      const a = await db.prepare("SELECT * FROM news_accounts WHERE username=?").bind(username).first<NewsAccount>();
      const hash = await passwordHash(typeof password === "string" && password.length <= 128 ? password : "", a?.salt ?? "invalid-account-salt-00000000000000");
      if (!a || !a.enabled || !equal(hash, a.password_hash)) fail("Неверный логин или пароль.", 401);
      const token = random();
      await db.prepare("INSERT INTO news_sessions (token_hash,username,expires_at) VALUES (?,?,?)").bind(await digest(token), a.username, now + 8 * 3600000).run();
      await db.batch([db.prepare("DELETE FROM news_sessions WHERE expires_at<?").bind(now), db.prepare("DELETE FROM news_login_limits WHERE expires_at<?").bind(now)]);
      return json({ user: publicAccount(a) }, { "Set-Cookie": sessionCookie(token, 8 * 3600) });
    }
    if (resource === "logout" && method === "POST") {
      const token = request.headers.get("cookie")?.split(";").map(s => s.trim()).find(s => s.startsWith(cookieName + "="))?.slice(cookieName.length + 1);
      if (token) await db.prepare("DELETE FROM news_sessions WHERE token_hash=?").bind(await digest(token)).run();
      return json({ ok: true }, { "Set-Cookie": sessionCookie("", 0) });
    }
    if (resource === "password" && method === "POST") {
      const a = await required(db, request, true), { currentPassword, password } = await payload(request);
      if (typeof currentPassword !== "string" || currentPassword.length > 128 || !equal(await passwordHash(currentPassword, a.salt), a.password_hash)) fail("Текущий пароль неверен.", 403);
      if (!passwordValid(password) || password === currentPassword) fail("Новый пароль: 12–128 символов, буквы и цифры. Он должен отличаться от текущего.");
      const salt = random();
      await db.batch([db.prepare("UPDATE news_accounts SET salt=?,password_hash=?,must_change=0 WHERE username=?").bind(salt, await passwordHash(password, salt), a.username), db.prepare("DELETE FROM news_sessions WHERE username=?").bind(a.username)]);
      return json({ ok: true }, { "Set-Cookie": sessionCookie("", 0) });
    }
    if (resource === "accounts") {
      const a = await required(db, request); if (a.role !== "admin") fail("Управление доступом доступно только администратору.", 403);
      if (method === "GET") return json({ users: (await db.prepare("SELECT * FROM news_accounts ORDER BY username").all<NewsAccount>()).results.map(publicAccount) });
      if (method === "PATCH" && id === "editor") {
        const body = await payload(request);
        if (body.password !== undefined) {
          if (!passwordValid(body.password)) fail("Пароль: 12–128 символов, буквы и цифры.");
          const salt = random(); await db.prepare("UPDATE news_accounts SET salt=?,password_hash=?,must_change=1 WHERE username='editor'").bind(salt, await passwordHash(body.password, salt)).run();
        } else if (typeof body.enabled === "boolean") await db.prepare("UPDATE news_accounts SET enabled=? WHERE username='editor'").bind(body.enabled ? 1 : 0).run();
        else fail("Укажите новый пароль или состояние доступа.");
        await db.prepare("DELETE FROM news_sessions WHERE username='editor'").run(); return json({ ok: true });
      }
    }
    if (resource === "feed" && method === "GET") {
      const rows = (await db.prepare("SELECT * FROM news_posts WHERE status='published' ORDER BY event_date DESC,updated_at DESC").all<NewsPost>()).results;
      return json({ posts: await Promise.all(rows.map(row => withAssets(db, row))) });
    }
    if (resource === "assets" && method === "GET" && id) {
      const asset = await db.prepare("SELECT * FROM news_assets WHERE id=?").bind(id).first<Asset>(); if (!asset) fail("Фото не найдено.", 404);
      const row = await post(db, asset.post_id); if (row.status !== "published") await required(db, request);
      const file = await (await courseBucket()).get(asset.storage_key); if (!file) fail("Фото не найдено.", 404);
      return new Response(file.body, { headers: { ...headers, "Content-Type": asset.mime, "X-Content-Type-Options": "nosniff", "Content-Disposition": "inline" } });
    }
    await required(db, request);
    if (resource === "posts") {
      if (method === "GET") return json({ posts: await Promise.all((await db.prepare("SELECT * FROM news_posts ORDER BY updated_at DESC").all<NewsPost>()).results.map(row => withAssets(db, row))) });
      if (method === "POST" || method === "PATCH" && id) {
        const body = await payload(request);
        if (typeof body.kind !== "string" || !["news", "album"].includes(body.kind) || typeof body.title !== "string" || !body.title.trim() || body.title.length > 180 || typeof body.body !== "string" || body.body.length > 30000 || typeof body.category !== "string" || body.category.length > 80 || typeof body.event_date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(body.event_date) || !Number.isFinite(Date.parse(body.event_date)) || typeof body.status !== "string" || !["draft", "published"].includes(body.status)) fail("Проверьте название, дату и текст публикации.");
        const previous = id ? await post(db, id) : null;
        if (body.status === "published" && body.kind === "album" && (!id || !(await assets(db, id)).length)) fail("Добавьте хотя бы одно фото в альбом перед публикацией.");
        const postId = id || crypto.randomUUID(), now = new Date().toISOString();
        const values = [body.kind, body.title.trim(), body.body, body.category.trim(), body.event_date, body.status, now];
        if (previous) {
          const result = await db.prepare("UPDATE news_posts SET kind=?,title=?,body=?,category=?,event_date=?,status=?,updated_at=?,version=version+1 WHERE id=? AND version=?").bind(...values, postId, body.version).run();
          if (!result.meta.changes) fail("Публикацию уже изменили. Обновите список и откройте её заново.", 409);
        } else await db.prepare("INSERT INTO news_posts (kind,title,body,category,event_date,status,updated_at,id) VALUES (?,?,?,?,?,?,?,?)").bind(...values, postId).run();
        return json({ post: await withAssets(db, await post(db, postId)) });
      }
      if (method === "DELETE" && id) {
        await post(db, id); const files = await assets(db, id);
        await db.batch([db.prepare("DELETE FROM news_assets WHERE post_id=?").bind(id), db.prepare("DELETE FROM news_posts WHERE id=?").bind(id)]);
        const bucket = files.length ? await courseBucket() : null; if (bucket) await Promise.all(files.map(file => bucket.delete(file.storage_key)));
        return json({ ok: true });
      }
    }
    if (resource === "upload" && method === "POST" && id) {
      await post(db, id);
      if (Number(request.headers.get("content-length")) > 6 * 1024 * 1024) fail("Фото должно быть не больше 5 МБ.", 413);
      const form = await request.formData(), file = form.get("photo"); if (!(file instanceof File)) fail("Выберите фото.");
      const image = await validateProfilePhoto(file).catch(e => fail(e.message)), assetId = crypto.randomUUID(), key = `news/${id}/${assetId}`, bucket = await courseBucket();
      await bucket.put(key, image.bytes, { httpMetadata: { contentType: image.mime } });
      try {
        const result = await db.prepare("INSERT INTO news_assets (id,post_id,storage_key,mime,name) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM news_posts WHERE id=?) AND (SELECT COUNT(*) FROM news_assets WHERE post_id=?)<20").bind(assetId, id, key, image.mime, file.name.slice(0, 180), id, id).run();
        if (!result.meta.changes) fail("Не больше 20 фото в одной публикации.");
      } catch (e) { await bucket.delete(key); throw e; }
      return json({ post: await withAssets(db, await post(db, id)) });
    }
    if (resource === "assets" && method === "DELETE" && id) {
      const file = await db.prepare("SELECT * FROM news_assets WHERE id=?").bind(id).first<Asset>(); if (!file) fail("Фото не найдено.", 404);
      const row = await post(db, file.post_id);
      if (row.kind === "album" && row.status === "published" && (await assets(db, row.id)).length === 1) fail("Сначала снимите альбом с публикации, чтобы удалить последнее фото.");
      await db.prepare("DELETE FROM news_assets WHERE id=?").bind(id).run(); await (await courseBucket()).delete(file.storage_key);
      return json({ post: await withAssets(db, await post(db, row.id)) });
    }
    fail("Страница не найдена.", 404);
  } catch (e) {
    const error = e as Error & { status?: number };
    const status = error.status || (error instanceof SyntaxError ? 400 : 500);
    return Response.json({ error: { message: status === 500 ? "Не удалось выполнить действие. Повторите попытку." : error.message } }, { status, headers });
  }
}
