export type PortalPerson = {
  userId: string;
  name: string;
  role: string;
  departmentId: string;
  department: string;
  managerId: string | null;
  email: string;
  isNewEmployee?: boolean;
};

export const people: PortalPerson[] = [
  {
    userId: "u-irina",
    name: "Ирина Марухленко",
    role: "Ведущий менеджер по закупкам",
    departmentId: "import-procurement",
    department: "Импортные закупки",
    managerId: "u-manager",
    email: "i.marukhlenko@holdingbio.ru",
  },
  {
    userId: "u-anastasia",
    name: "Анастасия Воронцова",
    role: "Менеджер по закупкам",
    departmentId: "import-procurement",
    department: "Импортные закупки",
    managerId: "u-manager",
    email: "a.vorontsova@holdingbio.ru",
    isNewEmployee: true,
  },
  {
    userId: "u-maria",
    name: "Марина Крылова",
    role: "Ведущий менеджер",
    departmentId: "import-procurement",
    department: "Импортные закупки",
    managerId: "u-manager",
    email: "m.krylova@holdingbio.ru",
  },
  {
    userId: "u-manager",
    name: "Алексей Соколов",
    role: "Руководитель отдела импортных закупок",
    departmentId: "import-procurement",
    department: "Импортные закупки",
    managerId: "u-executive",
    email: "a.sokolov@holdingbio.ru",
  },
  {
    userId: "u-executive",
    name: "Анна Смирнова",
    role: "Директор по закупкам",
    departmentId: "procurement-branch",
    department: "Дирекция по закупкам",
    managerId: "u-ceo",
    email: "a.smirnova@holdingbio.ru",
  },
  {
    userId: "u-dealer",
    name: "Дмитрий Романов",
    role: "Менеджер дилерского отдела",
    departmentId: "dealer",
    department: "Дилерский отдел",
    managerId: "u-dealer-manager",
    email: "d.romanov@holdingbio.ru",
  },
];

