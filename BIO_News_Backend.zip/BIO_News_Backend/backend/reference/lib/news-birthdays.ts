// Fictional staff cards used in the news section. IDs, names and recipients
// are resolved here rather than accepted from a congratulation request.
export const newsBirthdays = [
  { id: "u-petrova", day: 10, month: 8, initials: "МП", name: "Мария Петрова", meta: "10 августа · Маркетинг", tone: "yellow", photo: "/portraits/maria.png", position: "center 28%" },
  { id: "u-manager", day: 12, month: 8, initials: "АС", name: "Алексей Соколов", meta: "12 августа · Логистика", tone: "blue", photo: "/portraits/alexey.png", position: "center 28%" },
  { id: "u-elena", day: 18, month: 8, initials: "ЕК", name: "Елена Крылова", meta: "18 августа · Финансы", tone: "purple", photo: "/portraits/elena.png", position: "center 28%" },
  { id: "u-dealer", day: 21, month: 8, initials: "ДР", name: "Дмитрий Романов", meta: "21 августа · Продажи", tone: "green", photo: "/portraits/dmitry.png", position: "center 28%" },
];
export type NewsBirthday = typeof newsBirthdays[number];
export function birthdaysInMonth(month: number) { return newsBirthdays.filter(person => person.month === month).sort((a, b) => a.day - b.day || a.name.localeCompare(b.name, "ru")); }

export function moscowBirthdayDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en", { timeZone: "Europe/Moscow", day: "numeric", month: "numeric" }).formatToParts(date);
  return { day: Number(parts.find(p => p.type === "day")?.value), month: Number(parts.find(p => p.type === "month")?.value) };
}
export function birthdaysToday(date = new Date()) { const today = moscowBirthdayDate(date); return birthdaysInMonth(today.month).filter(person => person.day === today.day); }
