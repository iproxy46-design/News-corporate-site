export const weeklyPoll = {
  id: "bio-corporate-events-v1",
  question: "Надо ли что-то менять в организации корпоративов?",
  options: [
    { id: "countryside", label: "Турбаза" },
    { id: "restaurant", label: "Ресторан" },
    { id: "either", label: "Подходит и ресторан, и турбаза" },
    { id: "office", label: "Встреча в офисе" },
    { id: "not-attending", label: "Не планирую участвовать" },
  ],
};
export type WeeklyPollResult = {
  id: string; question: string; selected: string | null; total: number;
  options: { id: string; label: string; count: number; percentage: number }[];
};
