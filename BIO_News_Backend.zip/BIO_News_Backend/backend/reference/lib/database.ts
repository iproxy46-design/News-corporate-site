export async function portalDb(): Promise<D1Database> {
  const injected = (
    globalThis as typeof globalThis & { __BIO_PORTAL_TEST_DB__?: D1Database }
  ).__BIO_PORTAL_TEST_DB__;
  if (injected) return injected;
  const { env } = await import("cloudflare:workers");
  const db = env.DB;
  if (!db) throw new Error("D1 binding DB is unavailable");
  return db;
}
