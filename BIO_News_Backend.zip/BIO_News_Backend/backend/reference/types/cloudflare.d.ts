interface D1Result<T = Record<string, unknown>> { results: T[]; success: boolean; meta: { changes: number; [key: string]: unknown }; }
interface D1PreparedStatement {
  bind(...values: unknown[]): D1PreparedStatement;
  all<T = Record<string, unknown>>(): Promise<D1Result<T>>;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  run<T = Record<string, unknown>>(): Promise<D1Result<T>>;
}
interface D1Database { prepare(sql: string): D1PreparedStatement; batch<T = Record<string, unknown>>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>; }
interface R2ObjectBody { customMetadata?: Record<string,string>; httpMetadata?: { contentType?: string }; arrayBuffer(): Promise<ArrayBuffer>; body: ReadableStream; }
interface R2Bucket {
  put(key: string, value: Uint8Array | ArrayBuffer | ReadableStream, options?: { httpMetadata?: { contentType?: string }; customMetadata?: Record<string,string> }): Promise<unknown>;
  get(key: string, options?: { range?: { offset: number; length: number } }): Promise<R2ObjectBody | null>;
  delete(key: string): Promise<void>;
}
interface Fetcher { fetch(request: Request | string, init?: RequestInit): Promise<Response>; }
declare module "cloudflare:workers" { export const env: { DB: D1Database; BUCKET?: R2Bucket; NEWS_INITIAL_ACCOUNTS?: string }; }
