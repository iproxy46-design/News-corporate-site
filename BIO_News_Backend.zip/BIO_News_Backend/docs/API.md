# API раздела «Новости»

Все пути относительные, ответы — JSON, ошибки — `{ "error": { "message": "..." } }`.
Чувствительные ответы: `Cache-Control: private, no-store`. Изменения принимаются только с допустимого Origin.

## Читатель портала

Идентичность сотрудника должна приходить из доверенной серверной сессии/SSO. Нельзя принимать userId,
роль или email из тела запроса как доказательство права доступа. В исходном портале Sites устанавливает
`oai-authenticated-user-*`; при переносе замените это доверенным серверным адаптером. Не доверяйте таким
заголовкам, если клиент может прислать их напрямую.

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/api/news/weekly-poll` | Текущий опрос, выбранный ответ сотрудника и общие результаты |
| PUT | `/api/news/weekly-poll` | `{ "optionId": "restaurant" }`; один голос сотрудника, повторный запрос заменяет ответ |
| GET | `/api/birthdays/likes` | Счётчики и собственные лайки-поздравления |
| PUT | `/api/birthdays/likes` | `{ "recipientId": "u-petrova", "liked": true }`; false отменяет поздравление |
| GET | `/api/birthdays/balloons` | Совместимость с прежними шариками-поздравлениями |
| POST | `/api/birthdays/balloons` | `{ "recipientId": "u-manager" }`; один шарик за год |
| GET | `/api/gallery/favorites` | `{ "photoIds": ["team-meeting-2026"] }` |
| PUT | `/api/gallery/favorites` | `{ "photoId": "team-meeting-2026", "favorite": true }` |
| GET | `/api/news-cms/feed` | Опубликованные новости и альбомы: `{ "posts": [...] }` |
| GET | `/api/news-cms/assets/:id` | Бинарное фото; для черновиков нужна сессия редакции |

Пример опроса:

```json
{"id":"bio-corporate-events-v1","question":"Надо ли что-то менять в организации корпоративов?","selected":"restaurant","total":2,"options":[{"id":"restaurant","label":"Ресторан","count":1,"percentage":50}]}
```

В реальном ответе возвращаются **все пять** вариантов из `src/lib/news-weekly-poll.ts`.

Пример поздравлений:

```json
{"year":"2026","items":[{"recipientId":"u-petrova","count":1,"liked":true,"canLike":true}]}
```

Лайк должен сохраняться вместе с уведомлением имениннику одной транзакцией. Нельзя поздравлять себя.
Повтор одного запроса не создаёт дубли. В результатах не раскрывается список проголосовавших.

## Редакция: admin / editor

Это отдельная сессия только раздела «Новости», не роли других модулей портала.

| Метод | Путь | Данные / результат |
|---|---|---|
| GET | `/api/news-cms/session` | `{ "user": null }` или user с username, role, mustChangePassword, enabled |
| POST | `/api/news-cms/login` | `{ "username": "editor", "password": "..." }`; устанавливает HttpOnly-cookie |
| POST | `/api/news-cms/logout` | `{}`; отзывает текущую сессию |
| POST | `/api/news-cms/password` | `{ "currentPassword": "...", "password": "..." }`; отзывает все сессии пользователя |
| GET | `/api/news-cms/posts` | Все материалы редакции, включая черновики |
| POST | `/api/news-cms/posts` | Создать материал по структуре ниже |
| PATCH | `/api/news-cms/posts/:id` | Изменить материал; поле version обязательно для защиты от перезаписи |
| DELETE | `/api/news-cms/posts/:id` | Удалить материал и связанные фотографии |
| POST | `/api/news-cms/upload/:postId` | multipart/form-data, поле photo, один JPG/PNG/WebP до 5 МБ |
| DELETE | `/api/news-cms/assets/:id` | Удалить фото; у опубликованного альбома нельзя удалить последнее |
| GET | `/api/news-cms/accounts` | Только admin; состояния учётных записей |
| PATCH | `/api/news-cms/accounts/editor` | Только admin; `{ "enabled": false }` либо `{ "password": "новый временный пароль" }` |

Создание:

```json
{"kind":"news","title":"Заголовок","body":"Текст","category":"Компания","event_date":"2026-11-05","status":"draft"}
```

Ответ POST/PATCH: `{ "post": { ... } }`. У post есть `id`, `kind` (news/album), `title`, `body`,
`category`, `event_date`, `status` (draft/published), `version`, `updated_at`,
`assets: [{ "id": "...", "name": "photo.jpg", "url": "/api/news-cms/assets/..." }]`.
GET-списки возвращают `{ "posts": [...] }`.

До 20 фото на материал. Альбом сначала сохраняется черновиком, затем загружаются фотографии, затем публикуется.
Конфликт version — 409. Неверная аутентификация — 401. Нет прав/недопустимый Origin — 403.
Ограничение попыток входа — 429. Неизвестный объект — 404. Ошибка в данных — 400.
Сервер не возвращает password_hash, salt и токены сессий в JSON.

Сессия reference-реализации: `__Host-bio_news`, Secure, HttpOnly, SameSite=Strict, срок 8 часов.
Пароли 12–128 символов, буквы и цифры; временный пароль обязательно заменяется при первом входе.
В reference используется PBKDF2-SHA256/100000 итераций. При адаптации храните версионируемый формат хеша
и примените принятую в вашей системе политику паролей. Никаких действующих credentials в архиве нет.
